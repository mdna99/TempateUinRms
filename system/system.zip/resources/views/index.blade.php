@extends('layouts.base')

@section('content')
<video class="video" muted="muted" autoplay="" loop="">
    <source src="{{ asset(data_get($setting, 'video', '-')) }}" type="video/webm">
</video>
<div class="container home">
    @if(count($latestnews) != 0)
    <div class="latest-news">
        <div class="row">
            @foreach($latestnews->chunk(1) as $news)
            @foreach($news as $item)
            @if($loop->parent->first)
            <div class="col-md-5">
                <img class="latest-img" src="{{ asset($item->cover) }}" alt="{{ $item->title }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';">
            </div>
            <div class="col-md-7">
                <h1>{{ __('homepage.latest_news') }}</h1>
                <div class="latest">
                    <h3>{{ $item->formatted_published_at }}</h3>
                    <h2>{{ $item->title }}</h2>
                    <p>{{ Str::limit(strip_tags($item->description), 450) }}</p>
                    <a href="{{ generateUrl($item->slug) }}">{{ __('homepage.read_more') }}</a>
                </div>
            </div>
            @else
            <div class="col-md-4">
                <div class="item">
                    <img src="{{ asset($item->cover) }}" alt="{{ $item->title }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';">
                    <div class="content">
                        <h3>{{ $item->formatted_published_at }}</h3>
                        <h2>{{ $item->title }}</h2>
                        <a href="{{ generateUrl($item->slug) }}">{{ __('homepage.read_more') }}</a>
                    </div>
                </div>
            </div>
            @endif
            @endforeach
            @endforeach
        </div>
        <div class="w-100 text-center">
            <a href="{{ generateUrl($latestnews[0]->menu->slug) }}" class="btn btn-black">{{ __('homepage.more_news') }}</a>
        </div>
    </div>
    @endif
    @if($education)
    <div class="education">
        <div class="row">
            <div class="col-md-5">
                <img class="highlight-img" src="{{ asset($education->cover) }}" alt="{{ $education->title }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';">
            </div>
            <div class="col-md-7">
                <h1>{{ $education->title }}</h1>
                <div class="highlight">
                    <p>{{ Str::limit(strip_tags($education->description), 450) }}</p>
                    <a href="{{ generateUrl($education->slug) }}" class="btn btn-black">{{ __('homepage.more') }}</a>
                </div>
            </div>
        </div>
        <div class="row">
            @foreach($faculties as $faculty)
            <div class="col-md-6 col-lg-4">
                <div class="item-faculty">
                    <img src="{{ asset($faculty->cover) }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';" class="w-100">
                    <div class="title">
                        <a href="{{ generateUrl($faculty->slug) }}">{{ $faculty->title }}</a>
                    </div>
                </div>
            </div>
            @endforeach
            {{--
            @foreach($faculties as $faculty)
            <div class="col-md-4">
                <div class="item shadow">
                    <div class="title">
                        <h2>{{ $faculty->title }}</h2>
                    </div>
                    <p>{{ Str::limit(strip_tags($faculty->description), 250) }}</p>
                    <a href="{{ generateUrl($faculty->slug) }}">{{ __('homepage.read_more') }}</a>
                </div>
            </div>
            @endforeach
            --}}
        </div>
    </div>
    @endif
    @if(count($homemenus) != 0)
    @foreach($homemenus as $key => $homemenu)
    @if($key == 0)
    <div class="research">
        <div class="row">
            <div class="col-md-7">
                <h1>{{ $homemenu->title }}</h1>
                <p>{{ Str::limit(strip_tags($homemenu->description), 450) }}</p>
                <a href="{{ generateUrl($homemenu->slug) }}" class="btn btn-black">{{ __('homepage.more') }}</a>
            </div>
            <div class="col-md-5">
                <img src="{{ asset($homemenu->cover) }}" alt="{{ $homemenu->title }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';">
            </div>
        </div>
    </div>
    @elseif($key == 1)
    <div class="service">
        <div class="row">
            <div class="col-md-5">
                <img src="{{ asset($homemenu->cover) }}" alt="{{ $homemenu->title }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';">
            </div>
            <div class="col-md-7">
                <h1>{{ $homemenu->title }}</h1>
                <p>{{ Str::limit(strip_tags($homemenu->description), 450) }}</p>
                <a href="{{ generateUrl($homemenu->slug) }}" class="btn btn-black">{{ __('homepage.more') }}</a>
            </div>
        </div>
    </div>
    @elseif($key == 2)
    <div class="post">
        <div class="row">
            @if(isset($homemenu->posts[0]))
            <div class="col-md-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h2>{{ $homemenu->title }}</h2>
                    <a href="{{ generateUrl($homemenu->slug) }}">{{ __('homepage.other') }} <i class="fas fa-chevron-right"></i></a>
                </div>
                <div class="item shadow">
                    <img src="{{ asset($homemenu->posts[0]->cover) }}" alt="{{ $homemenu->posts[0]->title }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';">
                    <div class="text">
                        <h3>{{ $homemenu->posts[0]->title }}</h3>
                    </div>
                    <a href="{{ generateUrl($homemenu->posts[0]->slug) }}">{{ __('homepage.read_more') }}</a>
                </div>
            </div>
            @endif
            @else
            @if(isset($homemenu->posts[0]))
            <div class="col-md-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h2>{{ $homemenu->title }}</h2>
                    <a href="{{ generateUrl($homemenu->slug) }}">{{ __('homepage.other') }} <i class="fas fa-chevron-right"></i></a>
                </div>
                <div class="item shadow">
                    <img src="{{ asset($homemenu->posts[0]->cover) }}" alt="{{ $homemenu->posts[0]->title }}" onerror="this.src='{{ asset('files/no-image.jpg') }}';">
                    <div class="text">
                        <h3>{{ $homemenu->posts[0]->title }}</h3>
                    </div>
                    <a href="{{ generateUrl($homemenu->posts[0]->slug) }}">{{ __('homepage.read_more') }}</a>
                </div>
            </div>
            @endif
    @endif
    @if($loop->last && count($homemenus) > 2)
        </div>
        </div>
    @endif
    @endforeach
    @endif
</div>
@endsection

@push('script')
<script src='https://www.google.com/recaptcha/api.js'></script>
@endpush