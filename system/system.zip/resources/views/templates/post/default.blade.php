@extends('layouts.base')

@section('content')
<div class="container">
    <div class="detail-post">
        @include('components.breadcrumb', [
        'breadcrumbs' => $breadcrumbs
        ])
        <span>{{ $post->formatted_published_at }}</span>
        <h1>{{ $post->title }}</h1>
        <div class="row">
            <div class="col-md-8">
                {!! $post->description !!}
            </div>
            @if(isset($post->cover))
            <div class="col-md-4">
                <img src="{{ asset($post->cover) }}" alt="{{ $post->title }}" class="w-100">
            </div>
            @endif
        </div>
    </div>
</div>
@endsection