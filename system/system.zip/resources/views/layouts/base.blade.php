<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
    @if (App::environment('local'))
    <!--To prevent most search engine web crawlers from indexing a page on your site-->
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    @endif
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <title>{{ data_get($setting, 'name', '-') }}</title>
    <link rel="shortcut icon" href="{{ asset(data_get($setting, 'icon', '-')) }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="{{asset('css/style.css?ver=' . strtotime(date('Y-m-d H:i:s')))}}">
    @include('components.meta')
</head>

<body>
    <div class="navbar-second">
        <div class="link-container">
            @foreach($sidemenus as $sidemenu)
            <a class="link" href="{{ generateUrl($sidemenu->slug) }}">{{ $sidemenu->title }}</a>
            @endforeach
        </div>
        <div class="dropdown">
            <button class="btn dropdown-toggle" type="button" id="languange" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="d-flex align-items-center">
                    @if (app()->getLocale() == 'id')
                    <img src="{{ asset('assets/id.png') }}" style="width: 20px; margin-right: 5px">Indonesia
                    @elseif (app()->getLocale() == 'en')
                    <img src="{{ asset('assets/en.png') }}" style="width: 20px; margin-right: 5px">English
                    @else
                    <img src="{{ asset('assets/ar.png') }}" style="width: 20px; margin-right: 5px">Arabic
                    @endif
                </div>
            </button>
            <div class="dropdown-menu" aria-labelledby="languange">
                <a class="dropdown-item" href="{{ url('id') }}"><img src="{{ asset('assets/id.png') }}"> Indonesia</a>
                <a class="dropdown-item" href="{{ url('en') }}"><img src="{{ asset('assets/en.png') }}"> English</a>
                <a class="dropdown-item" href="{{ url('ar') }}"><img src="{{ asset('assets/ar.png') }}"> Arabic</a>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-main">
        <div class="top">
            <a class="navbar-brand shadow" href="{{ url('') }}">
                <img src="{{ asset(data_get($setting, 'icon', '-')) }}" alt="{{ data_get($setting, 'name', '-') }}">
            </a>
        </div>
        <div class="scroll d-none">
            <a class="navbar-brand" href="{{ url('') }}">
                <img src="{{ asset(data_get($setting, 'logo', '-')) }}" alt="{{ data_get($setting, 'name', '-') }}">
            </a>
        </div>
        <div class="d-flex" style="padding: 11px 0;">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-main" aria-controls="navbar-main" aria-expanded="false" aria-label="Toggle navigation" onclick="closeNavbarSecond()">
                <i class="fas fa-bars"></i>
            </button>
            <button class="btn text-white navbar-second-toggler" onclick="openNavbarSecond()">
                <i class="fas fa-ellipsis-v"></i>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="navbar-main">
            <ul class="navbar-nav">
                @foreach($mainmenus as $mainmenu)
                <li class="nav-item">
                    <a class="nav-link" href="{{ $mainmenu->type == 'menu' ? generateUrl($mainmenu->slug) : $menu->link }}">{{ $mainmenu->title }}</a>
                </li>
                @endforeach
            </ul>
            <form action="{{ generateUrl(trans('route.search')) }}" method="GET" accept-charset="utf-8" class="form-inline">
                <input class="form-control search-input" type="search" name="keyword" placeholder="{{ __('search.placeholder') }}" aria-label="Search" value="{{ request('keyword') }}">
                <i class="fas fa-search search-icon"></i>
            </form>
        </div>
    </nav>
    <div class="mt-87"></div>

    @yield('content')

    <footer>
        <div class="container-fluid">
            <div class="row footer">
                <div class="col-md-3 mb-4">
                    <div class="img">
                        <img src="{{ asset(data_get($setting, 'icon', '-')) }}" class="shadow">
                    </div>
                    <p class="address">{{ data_get($setting, 'address', '-') }}</p>
                    <div class="d-flex flex-column">
                        <a href="tel:{{ data_get($setting, 'phone', '-') }}"><i class="fas fa-phone"></i> {{ data_get($setting, 'phone', '-') }}</a>
                        <a href="fax:{{ data_get($setting, 'fax', '-') }}"><i class="fas fa-fax"></i> {{ data_get($setting, 'fax', '-') }}</a>
                        <a href="mailto:{{ data_get($setting, 'email', '-') }}"><i class="far fa-envelope"></i> {{ data_get($setting, 'email', '-') }}</a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="row">
                        @foreach($footer_items as $item)
                        <div class="col-md-6 col-lg-3 mb-4">
                            <h3>{{ $item->title }}</h3>
                            @if(isset($item->submenus))
                            <div class="d-flex flex-column">
                                @foreach($item->submenus as $submenu)
                                <a class="mb-2" href="{{ $submenu->website }}">{{ $submenu->title }}</a>
                                @endforeach
                            </div>
                            @endif
                            @if(isset($item->posts))
                            <div class="d-flex flex-column">
                                @foreach($item->posts as $post)
                                <a class="mb-1" href="{{ generateUrl($post->slug) }}">{{ $post->title }}</a>
                                @endforeach
                            </div>
                            @endif
                        </div>
                        @endforeach
                        <div class="col-md-6 col-lg-3 mb-2">
                            <h3>{{ __('footer.follow_us') }}</h3>
                            <div class="d-flex flex-column">
                                @foreach($social_media as $sm)
                                <a class="mb-1" href="{{ $sm->link }}"><i class="{{ $sm->icon }}"></i> {{ $sm->name }}</a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <p class="copyright">© {{ date('Y') }} {{ data_get($setting, 'name', '-') }}</p>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js" data-cover></script>
    <script type="text/javascript" src="{{asset('js/script.js?ver=' . strtotime(date('Y-m-d H:i:s')))}}"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    @stack('script')
</body>

</html>