<?php

return [
    'placeholder' => 'Pencarian',
    'search_result' => 'Hasil Pencarian',
    'no_data' => 'Tidak Ada Data'
];
