<?php

return [
    'tab_menu' => 'Menu Tab',
];