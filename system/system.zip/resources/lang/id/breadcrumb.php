<?php

return [
    
    'home' => 'Beranda',
];