<?php

return [
    'follow_us' => 'Ikuti Kami di',
];
