<?php

return [    
    'latest_news' => 'Berita Terkini',
    'read_more' => 'Baca Selengkapnya',
    'more_news' => 'Berita Lainnya',
    'more' => 'Selengkapnya',
    'other' => 'Lainnya'
];