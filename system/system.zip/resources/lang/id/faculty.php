<?php

return [
    'address' => 'Alamat',
    'phone' => 'Telepon',
    'fax' => 'Fax',
    'email' => 'Email',
    'website' => 'Website',
    'visit_website' => 'Kunjungi Website',
];
