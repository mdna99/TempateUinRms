<?php

return [
    'follow_us' => 'تابعنا',
];
