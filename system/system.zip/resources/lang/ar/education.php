<?php

return [
    'detail' => 'التفاصيل',
];
