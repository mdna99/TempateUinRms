<?php

return [
    'placeholder' => 'بحث',
    'search_result' => 'نتيجة البحث',
    'no_data' => 'لايوجد بيانات',

];
