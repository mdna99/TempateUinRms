<?php

return [
    'address' => 'عنوان',
    'phone' => 'هاتف',
    'fax' => 'فاكس',
    'email' => 'بريد الالكتروني',
    'website' => 'موقع الكتروني',
    'visit_website' => 'زيارة الموقع',
];
