<?php

return [
    'latest_news' => 'أحدث الأخبار',
    'read_more' => 'اقرأ أكثر',
    'more_news' => 'المزيد من الأخبار',
    'more' => 'أكثر',
    'other' => 'آخر',
];
