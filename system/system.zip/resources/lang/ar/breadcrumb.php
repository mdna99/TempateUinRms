<?php

return [
    
    'home' => 'الصفحة الرئيسية',
];