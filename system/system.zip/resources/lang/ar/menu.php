<?php

return [
    'tab_menu' => 'قائمة علامة التبويب',
];