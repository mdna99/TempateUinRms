<?php

return [
    
    'home' => 'Home',
];