<?php

return [
    'placeholder' => 'Search',
    'search_result' => 'Search Result',
    'no_data' => 'No Data'

];
