<?php

return [
    'address' => 'Address',
    'phone' => 'Phone',
    'fax' => 'Fax',
    'email' => 'Email',
    'website' => 'Website',
    'visit_website' => 'Visit Website',
];
