<?php

return [
    'latest_news' => 'Latest News',
    'read_more' => 'Read More',
    'more_news' => 'More News',
    'more' => 'More',
    'other' => 'Other'
];
