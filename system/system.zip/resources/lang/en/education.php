<?php

return [
    'detail' => 'Detail',
];
