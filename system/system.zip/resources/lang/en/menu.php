<?php

return [
    'tab_menu' => 'Tab Menu',
];