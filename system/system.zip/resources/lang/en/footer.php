<?php

return [
    'follow_us' => 'Follow Us',
];
