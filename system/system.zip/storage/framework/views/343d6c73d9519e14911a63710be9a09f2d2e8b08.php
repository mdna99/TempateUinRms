<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
        <?php if(App::environment('local')): ?>
        <!--To prevent most search engine web crawlers from indexing a page on your site-->
        <meta name="robots" content="noindex">
        <meta name="googlebot" content="noindex">
        <?php endif; ?>
        <title><?php echo e(data_get($setting, 'name', '-')); ?></title>
        <link rel="shortcut icon" href="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css?ver=' . strtotime(date('Y-m-d H:i:s')))); ?>">
        <?php echo $__env->make('components.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body id="body">
        <div class="topbar">
            <div class="d-flex justify-content-between">
                <div class="logo">
                    <a href="<?php echo e(url('')); ?>">
                        <img src="<?php echo e(asset(data_get($setting, 'logo', '-'))); ?>">
                    </a>
                </div>
                <div class="socmed d-flex justify-content-between">
                    <?php $__currentLoopData = $social_media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialmedia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($socialmedia->link); ?>" target="_blank">
                        <i class="<?php echo e($socialmedia->icon); ?>"></i>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
        <div class="footer">
            <div class="d-flex align-items-center justify-content-between">
                <p class="copyright">Copyright © 2019 <?php echo e(data_get($setting, 'name', '-')); ?>. All Right Reserved</p>
                <div class="policy">
                    <?php $__currentLoopData = $footer_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('/pages/'.$post->slug)); ?>"><?php echo e($post->title); ?></a>
                    <?php echo e($loop->iteration != count($footer_posts) ? '|' : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js" data-cover></script>
        <script type="text/javascript" src="<?php echo e(asset('js/script.js?ver=' . strtotime(date('Y-m-d H:i:s')))); ?>"></script>
        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/layouts/base.blade.php ENDPATH**/ ?>