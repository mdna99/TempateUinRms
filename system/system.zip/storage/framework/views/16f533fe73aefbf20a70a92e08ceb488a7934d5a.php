<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.title', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="banner">
    <img src="<?php echo e(asset($cover)); ?>" onerror="this.src='<?php echo e(asset('assets/img/slider.JPG')); ?>'">
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid">
    <div class="post">
        <div class="row">
            <?php echo $__env->make('components.sidebar', [
            'sidebars' => $sidebars
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-8" id="print-area">
                <div class="content">
                    <h1><?php echo e($post->title); ?></h1>
                    <div class="location">
                        <div class="form-group row align-items-center">
                            <label for="name" class="col-sm-3 col-form-label"><?php echo e(__('location.choose')); ?></label>
                            <div class="col-sm-9">
                                <select class="form-control" id="selector" name="id">
                                    <option value="*">ALL</option>
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </select>
                            </div>
                        </div>
                        <?php echo $post->description; ?>  
                        <div id="location-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>NO</th>
                                        <th>AREA</th>
                                        <th>UNIT</th>
                                        <th>ADDRESS</th>
                                        <th>PHONE</th>
                                        <th>FAX</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($locations) != 0): ?>
                                    <?php
                                    $rowNumber = ($locations->currentpage()-1) * $locations->perpage() + 1;
                                    ?>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($rowNumber++); ?></td>
                                        <td><?php echo e($location->area->name); ?></td>
                                        <td><?php echo e($location->unit); ?></td>
                                        <td>
                                            <?php echo $location->address; ?>

                                        </td>
                                        <td><?php echo e($location->phone); ?></td>
                                        <td><?php echo e($location->fax); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="6">No data</td>
                                    </tr>
                                    <?php endif; ?>                                
                                </tbody>
                            </table>
                            <?php if(count($locations->links()->elements[0]) > 1): ?>
                            <?php echo e($locations->links('components.pagination')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if($post->thumbnail): ?>
        <img src="<?php echo e(asset($post->thumbnail)); ?>" class="cover">
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('#selector').change(function () {
        var id = $(this).find(':selected').val();
        if (id === '*') {
            location.reload();
        } else {
            $.ajax({
                type: 'POST',
                url: '<?php echo e(generateUrl('search-location')); ?>',
                data: {
                    'id': id
                },
                success: function (response) {
                    console.log(response);
                    $('#location-table').html(response);
                }
            });
        }
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/templates/location/index.blade.php ENDPATH**/ ?>