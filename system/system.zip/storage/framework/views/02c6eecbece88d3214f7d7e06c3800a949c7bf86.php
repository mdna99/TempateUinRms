<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
        <?php if(App::environment('local')): ?>
        <!--To prevent most search engine web crawlers from indexing a page on your site-->
        <meta name="robots" content="noindex">
        <meta name="googlebot" content="noindex">
        <?php endif; ?>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <title><?php echo e(data_get($setting, 'name', '-')); ?></title>
        <link rel="shortcut icon" href="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css?ver=' . strtotime(date('Y-m-d H:i:s')))); ?>">        
        <link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials.css" />
        <link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials-theme-plain.css" />
        <?php echo $__env->make('components.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>       
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-light">
            <a href="<?php echo e(url('')); ?>" class="navbar-brand">
                <img src="<?php echo e(asset(data_get($setting, 'logo', '-'))); ?>">
            </a>
            <button type="button" data-toggle="collapse" data-target="#navbarContent" class="navbar-toggler">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div id="navbarContent" class="collapse navbar-collapse navbar-content">
                <ul class="navbar-nav">
                    <?php echo $__env->make('components.menu', [
                    'menus' => $main_menus
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
                <div class="icon">
                    <a href="javascript:void(0)" onclick="searchBox()"><i class="fas fa-search"></i></a>
                    <a href="<?php echo e(generateUrlByPostId(4)); ?>"><i class="far fa-envelope"></i></a>
                    <?php if(app()->getLocale() == 'id'): ?>
                    <a href="<?php echo e(url('en')); ?>">
                        <img class="flag" src="<?php echo e(asset('assets/img/en.png')); ?>">
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(url('id')); ?>">
                        <img class="flag" src="<?php echo e(asset('assets/img/id.png')); ?>">
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
        <div class="main-border">
            <div class="red"></div>
            <div class="blue"></div>
        </div>
        <form action="<?php echo e(generateUrl(trans('route.search'))); ?>" method="GET" accept-charset="utf-8">
            <div id="search-box">
                <div class="search-box">
                    <input type="text" name="query" class="form-control" placeholder="<?php echo e(__('search.placeholder')); ?>">
                    <button type="submit" class="btn btn-blue-gradient"><?php echo e(__('search.button')); ?></button>
                    <i class="fas fa-times" onclick="searchBox()"></i>
                </div>
            </div>
        </form>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('components.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="footer">
            <div class="footer-top" id="footer-top">
                <div class="socmed">
                    <?php $__currentLoopData = $social_media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socmed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($socmed->link); ?>"><i class="<?php echo e($socmed->icon); ?>"></i></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="info">
                    <img src="<?php echo e(asset(data_get($setting, 'logo', '-'))); ?>">
                    <p><?php echo e(data_get($setting, 'address', '-')); ?></p>
                    <p>Telp: <?php echo e(data_get($setting, 'phone', '-')); ?> Fax: <?php echo e(data_get($setting, 'fax', '-')); ?> | Email: <span><?php echo e(data_get($setting, 'email', '-')); ?></span></p>
                    <div class="award">
                        <img src="<?php echo e(asset(data_get($setting, 'award', '-'))); ?>">
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p><?php echo e(__('homepage.footer')); ?></p>
                <p>
                    <?php $__currentLoopData = $footer_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(generateUrl($post->slug)); ?>"><?php echo e($post->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js" data-cover></script>
        <script type="text/javascript" src="<?php echo e(asset('js/jssocials.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/script.js?ver=' . strtotime(date('Y-m-d H:i:s')))); ?>"></script>        
        <script>
                            $.ajaxSetup({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                }
                            });
        </script>
        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/layouts/base.blade.php ENDPATH**/ ?>