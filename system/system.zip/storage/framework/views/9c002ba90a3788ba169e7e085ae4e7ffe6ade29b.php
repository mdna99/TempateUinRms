<?php $__env->startSection('content'); ?>
<div class="sidebar">
    <ul>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        if($menu->id == 1){
        $i = '#home';
        } else
        if($menu->id == 2){
        $i = '#about';
        } else
        if($menu->id == 3){
        $i = '#service';
        } else
        if($menu->id == 4){
        $i = '#work';
        } else
        if($menu->id == 5){
        $i = '#contact';
        }
        ?>
        <a href="<?php echo e(url('/'.$i)); ?>">
            <li>
                <?php echo e($menu->title); ?>

            </li>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    </ul>
</div>
<div class="background" style="background-image: url(<?php echo e(asset($menu->cover)); ?>)">
    <div class="title">
        <h1><?php echo e($post->title); ?></h1>
    </div>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/post/show.blade.php ENDPATH**/ ?>