

<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <?php if($parent->parent_id == 0): ?>
    <a href="<?php echo e(route("cp.menus.show",$parent->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php else: ?>
    <a href="<?php echo e(route('cp.menus.submenus.show',[$parent->parent_id,$parent->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php endif; ?>
</div>
<h1><?php echo e($menu->title); ?></h1>&nbsp;<span class="badge badge-<?php echo e($menu->is_published == 1 ? 'primary' : 'warning'); ?>"><?php echo e($menu->is_published == 1 ? 'Published' : 'Draft'); ?></span>
<?php echo $__env->make('cp.components.breadcrumb', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-8">
        <div class="card">
            <div class="card-header py-0">
                <h4 class="text-black-50">Content</h4>
            </div>
            <div class="card-body py-0">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(app()->getLocale() == 'id' ? 'active' : ''); ?>" id="id-tab" data-toggle="tab" href="#id" role="tab" aria-controls="id" aria-selected="true">Indonesia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>" id="en-tab" data-toggle="tab" href="#en" role="tab" aria-controls="en" aria-selected="false">English</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade <?php echo e(app()->getLocale() == 'id' ? 'show active' : ''); ?>" id="id" role="tabpanel" aria-labelledby="id-tab">
                        <dl class="meta">
                            <dt>Title</dt>
                            <dd><?php echo e($menu->translate('id')->title); ?></dd>

                            <dt>Description</dt>
                            <dd><?php echo $menu->translate('id')->description; ?></dd>
                        </dl>    
                    </div>
                    <div class="tab-pane fade <?php echo e(app()->getLocale() == 'en' ? 'show active' : ''); ?>" id="en" role="tabpanel" aria-labelledby="en-tab">
                        <dl class="meta">
                            <dt>Title</dt>
                            <dd><?php echo e($menu->translate('en')->title); ?></dd>

                            <dt>Description</dt>
                            <dd><?php echo $menu->translate('en')->description; ?></dd>
                        </dl>       
                    </div>
                </div> 
            </div>
        </div>
    </div>
    <div class="col-4">
        <div class="card">
            <div class="card-header py-0">
                <h4 class="text-black-50">Meta</h4>
            </div>
            <div class="card-body py-0">
                <dl class="meta">
                    <dt>Cover</dt>
                    <dd>
                        <?php if($menu->cover): ?>
                        <img src="<?php echo e(asset($menu->cover)); ?>" class="img-fluid" onerror="this.style.display = 'none'">
                        <?php else: ?>
                        None
                        <?php endif; ?>
                    </dd>

                    <dt>Template Page</dt>
                    <dd><?php echo e($menu->template); ?></dd>
                </dl>  
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="section-title m-0">
                Submenu
            </h2>
            <a href="<?php echo e(route('cp.menus.submenus.create',$menu)); ?>" class="btn btn-primary">Add New Submenu</a>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-4">
        <div class="article">
            <div class="article-header">
                <div class="article-image d-flex justify-content-center align-items-center">
                    <img src="<?php echo e(asset($submenu->cover)); ?>" class="w-100" onerror="this.src='<?php echo e(asset('assets/img/nocover.png')); ?>';">
                </div>
                <div class="article-title">
                    <h2 class="text-light"><?php echo e($submenu->title); ?></h2>
                </div>
            </div>
            <div class="card-footer bg-whitesmoke">
                <div class="row align-items-center justify-content-between">
                    <div class="col-4 text-center"><a href="<?php echo e(route('cp.menus.submenus.show',[$menu, $submenu])); ?>" class="btn btn-sm btn-outline-success"><i class="fa fa-eye"></i> Detail</a></div>
                    <div class="col-4 text-center"><a href="<?php echo e(route('cp.menus.submenus.edit', [$menu, $submenu])); ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-pencil-alt"></i> Edit</a></div>
                    <div class="col-4 text-center">
                        <form id="form-action" method="POST" action="<?php echo e(route('cp.menus.submenus.destroy', [$menu, $submenu])); ?>" accept-charset="UTF-8">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Anda yakin akan menghapus data ?');">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12 text-center">  
        <div class="card card-primary">            
            <p class="m-0 py-3">Tidak Ada Data</p>
        </div>
    </div>
    <?php endif; ?>
</div>
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="section-title m-0">
                Post
            </h2>
            <a href="<?php echo e(route('cp.menus.posts.create',$menu)); ?>" class="btn btn-primary">Add New Post</a>
        </div>
        <div class="card card-primary">         
            <div class="card-body p-0">
                <table class="table table-striped table-md">
                    <thead>
                        <tr>
                            <th class="table-fit">#</th>
                            <th>Title</th>
                            <th class="table-fit">Published At</th>
                            <th></th>
                            <th class="table-fit">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $rowNumber = ($posts->currentpage()-1) * $posts->perpage() + 1;
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="table-fit"><?php echo e($rowNumber++); ?></td>
                            <td><?php echo e($post->title); ?></td>
                            <td class="table-fit"><?php echo e($post->created_at->format('d F Y')); ?></td>
                            <td class="table-fit">
                                <span class="badge badge-<?php echo e($post->is_published == 1 ? 'primary' : 'warning'); ?>"><?php echo e($post->is_published == 1 ? 'Published' : 'Draft'); ?></span>
                                <?php if($post->is_running_text == 1): ?>
                                <span class="badge badge-info">Running Text</span>
                                <?php endif; ?>
                                <?php if($post->is_featured_product == 1): ?>
                                <span class="badge badge-danger">Featured Product</span>
                                <?php endif; ?>
                            </td>
                            <td class="table-fit">
                                <form id="form-action" method="POST" action="<?php echo e(route('cp.menus.posts.destroy', [$menu,$post])); ?>" accept-charset="UTF-8">
                                    <input name="_method" type="hidden" value="DELETE">
                                    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">

                                    <div class="table-links">
                                        <a href="<?php echo e(route('cp.menus.posts.show',[$menu->id, $post->id])); ?>">Detail</a>
                                        <div class="bullet"></div>
                                        <a href="<?php echo e(route('cp.menus.posts.edit',[$menu->id, $post->id])); ?>">Edit</a>
                                        <div class="bullet"></div>
                                        <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Are you sure want to delete it ?');">
                                            Delete
                                        </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="px-2">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/dev/system/resources/views/cp/submenu/show.blade.php ENDPATH**/ ?>