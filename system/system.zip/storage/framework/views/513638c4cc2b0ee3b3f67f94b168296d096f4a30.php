<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.exchanges.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Edit Area</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.exchanges.update', $exchange)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Content</h4>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="date" class="col-sm-3 col-form-label text-right">Date</label>
                        <div class="col-sm-6">
                            <input type="text" id="date" class="form-control" value="<?php echo e($exchange->created_at->format('d-m-Y')); ?>" disabled="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="rate" class="col-sm-3 col-form-label text-right">Rate</label>
                        <div class="col-sm-6">
                            <input type="text" id="rate" class="form-control" value="<?php echo e($exchange->rate->name); ?>" disabled="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="sell" class="col-sm-3 col-form-label text-right">Sell</label>
                        <div class="col-sm-6">
                            <input type="text" id="sell" class="form-control<?php echo e($errors->has('sell') ? ' is-invalid' : ''); ?>" name="sell" autofocus="" value="<?php echo e($exchange->sell); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'sell'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="buy" class="col-sm-3 col-form-label text-right">Buy</label>
                        <div class="col-sm-6">
                            <input type="text" id="buy" class="form-control<?php echo e($errors->has('buy') ? ' is-invalid' : ''); ?>" name="buy" autofocus="" value="<?php echo e($exchange->buy); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'buy'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <div class="col-sm-6 offset-sm-3">
                        <button type="submit" class="btn btn-primary">
                            Save
                        </button>
                        <a href="<?php echo e(route('cp.exchanges.index')); ?>" class="btn btn-secondary">
                            Cancel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/cp/exchange/edit.blade.php ENDPATH**/ ?>