<?php $__env->startSection('title', 'Role'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-start mb-2">
    <h2 class="section-title m-0 mb-4">
        Data Role
    </h2>
    <a href="<?php echo e(route('cp.roles.create')); ?>" class="btn btn-primary">Add New</a>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="table-fit">#</th>
                                <th>Nama</th>
                                <th class="table-fit">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $rowNumber = ($roles->currentpage()-1) * $roles->perpage() + 1;
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="table-fit"><?php echo e($rowNumber++); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td class="table-fit">
                                    <form id="form-action" method="POST" action="<?php echo e(route('cp.roles.destroy', $item)); ?>" accept-charset="UTF-8">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>

                                        <div class="table-links">
                                            <a href="<?php echo e(route('cp.roles.edit', $item)); ?>">Edit</a>
                                            <div class="bullet"></div>
                                            <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Anda yakin akan menghapus data ?');">
                                                Delete
                                            </button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">Tidak ada data.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php echo e($roles->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/cp/role/index.blade.php ENDPATH**/ ?>