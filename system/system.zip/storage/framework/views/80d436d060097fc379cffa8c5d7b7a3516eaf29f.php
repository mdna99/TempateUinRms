

<?php $__env->startSection('title'); ?>
    <div class="section-header-back">
      <a href="<?php echo e(route('cp.contacts.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    </div>
    <h1>Detail Kontak Kami</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Message sent <?php echo e($contact->created_at->format('d F Y')); ?> - <?php echo e($contact->created_at->format('H:i')); ?></h4>
            </div>
            <div class="card-body">
                <dl class="row">
                    <dt class="col-2 text-right">Name</dt>
                    <dd class="col-10"><?php echo e($contact->name); ?></dd>
                    
                    <dt class="col-2 text-right">Address</dt>
                    <dd class="col-10"><?php echo e($contact->address); ?></dd>

                    <dt class="col-2 text-right">Phone</dt>
                    <dd class="col-10"><?php echo e($contact->phone); ?></dd>
                    
                    <dt class="col-2 text-right">Email</dt>
                    <dd class="col-10"><?php echo e($contact->email); ?></dd>
                    
                    <dt class="col-2 text-right">Message</dt>
                    <dd class="col-10"><?php echo e($contact->message); ?></dd>
                </dl>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/contact/show.blade.php ENDPATH**/ ?>