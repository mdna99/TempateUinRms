<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.title', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="banner">
    <img src="<?php echo e(asset($cover)); ?>" onerror="this.src='<?php echo e(asset('assets/img/slider.JPG')); ?>'">
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid">
    <div class="post">
        <div class="row">
            <div class="col-md-4 d-none d-md-block d-lg-block">
                <div class="sidebar">
                    <ul>
                        <?php $__currentLoopData = $menu->parent->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li <?php echo e($submenu->id == $menu->id ? 'class=active' : ''); ?>><a href="<?php echo e(generateUrl($submenu->slug)); ?>"><?php echo e($submenu->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8" id="print-area">
                <div class="content">
                    <div class="retirement-program">
                        <?php if(request('page') != null && request('page') == 'info'): ?>
                        <div class="description">
                            <div class="image">
                                <img src="<?php echo e(asset(data_get($setting, 'retirement_image_info'))); ?>">
                            </div>
                            <div class="text">
                            <h1><?php echo e(app()->getLocale() == 'id' ? data_get($setting, 'retirement_title_info_id') : data_get($setting, 'retirement_title_info_en')); ?></h1>
                                <?php echo app()->getLocale() == 'id' ? data_get($setting, 'retirement_description_info_id') : data_get($setting, 'retirement_description_info_en'); ?>

                            </div>
                        </div>
                        <div id="info" class="form">
                            <div class="title">
                                <h2>Select Function :</h2>
                                <div class="d-flex justify-content-between">
                                    <a class="calc active" href="<?php echo e(generateUrl($menu->slug)); ?>#calculation"><i class="fas fa-calculator"></i>&nbsp;&nbsp;&nbsp;Credit Calculator</a>
                                    <a href="<?php echo e(generateUrl($menu->slug)); ?>?page=info#info"><i>i</i>&nbsp;&nbsp;&nbsp;More Info</a>
                                </div>
                            </div>
                            <form action="<?php echo e(route('inbox.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(session('success')): ?>
                                <p class="text-center"><?php echo e(__('retirement.info_success')); ?></p>
                                <?php else: ?>
                                <p><?php echo e(__('retirement.info_title')); ?></p>
                                <p class="red text-uppercase"><?php echo e(__('retirement.required')); ?></p>
                                <div class="row">
                                    <div class="col-lg-6 border-right">
                                        <table class="w-100">
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.name')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="name" name="name" type="text" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.address')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="address" name="address" type="text" class="<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.phone')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="phone" name="phone" type="tel" class="<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" pattern="[0]{1}[8]{1}[0-9]{8,12}" required></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.email')); ?></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="email" name="email" type="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label" style="vertical-align: top;"><?php echo e(__('retirement.question')); ?><span class="red">*</span></td>
                                                <td class="table-fit" style="vertical-align: top;">:</td>
                                                <td><textarea id="message" name="message" rows="3" style="vertical-align: top;" class="<?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></textarea></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-lg-6">
                                        <h6><?php echo e(__('retirement.verification')); ?><span class="red">*</span></h6>
                                        <div class="g-recaptcha" data-sitekey="<?php echo e(config('app.recapcha_key')); ?>"></div>
                                        <div class="invalid-feedback <?php echo e($errors->has('g-recaptcha-response') ? 'd-block' : ''); ?>"><?php echo e($errors->has('g-recaptcha-response') ? $errors->first('g-recaptcha-response') : ''); ?></div>
                                        <button class="btn btn-blue-gradient text-uppercase">Submit</button>
                                    </div>
                                </div>                                
                                <?php endif; ?>
                            </form>
                        </div>
                        <?php else: ?>
                        <div class="description">
                            <div class="image">
                                <img src="<?php echo e(asset(data_get($setting, 'retirement_image'))); ?>">
                            </div>
                            <div class="text">
                                <h1><?php echo e(app()->getLocale() == 'id' ? data_get($setting, 'retirement_title_id') : data_get($setting, 'retirement_title_en')); ?></h1>
                                <?php echo app()->getLocale() == 'id' ? data_get($setting, 'retirement_description_id') : data_get($setting, 'retirement_description_en'); ?>

                            </div>
                        </div>
                        <div id="calculation" class="form">
                            <div class="title">
                                <h2>Select Function :</h2>
                                <div class="d-flex justify-content-between">
                                    <a class="calc" href="<?php echo e(generateUrl($menu->slug)); ?>#calculation"><i class="fas fa-calculator"></i>&nbsp;&nbsp;&nbsp;Credit Calculator</a>
                                    <a class="active" href="<?php echo e(generateUrl($menu->slug)); ?>?page=info#info"><i>i</i>&nbsp;&nbsp;&nbsp;More Info</a>
                                </div>
                            </div>
                            <form action="<?php echo e(route('calculate.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(session('error')): ?>
                                <h5 class="text-center red font-weight-bold"><?php echo e(__('retirement.calculation_error').' '.data_get($setting, 'credit_age').' '.__('retirement.year')); ?></h5>
                                <?php endif; ?>
                                <p><?php echo e(__('retirement.title')); ?></p>
                                <p class="red text-uppercase"><?php echo e(__('retirement.required')); ?></p>
                                <div class="row">
                                    <div class="col-lg-6 border-right">
                                        <table class="w-100">
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.name')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="name" name="name" type="text" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('name') ? old('name') : (session('success') ? session('success')['calculation']->name : '')); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.company')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="company" name="company" type="text" class="<?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('company') ? old('company') : (session('success') ? session('success')['calculation']->company : '')); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.birth_date')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="birth_date" name="birth_date" type="date" class="<?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('birth_date') ? old('birth_date') : (session('success') ? session('success')['calculation']->birth_date : '1960-01-01')); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.location')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td>
                                                    <select id="location" name="location" class="<?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                                        <option value="">Select location..</option>
                                                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('location') && old('location') == $area->name ? 'selected' : (session('success') && session('success')['calculation']->location == $area->name ? 'selected' : '')); ?>><?php echo e($area->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="Other" <?php echo e(session('success') && session('success')['calculation']->location_other == 1 ? 'selected' : ''); ?>>Other</option>
                                                    </select>
                                                    <input id="location_other" class="mt-1" name="location_other" type="text" value="<?php echo e(session('success') && session('success')['calculation']->location_other == 1 ? session('success')['calculation']->location : ''); ?>">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.phone')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="phone" name="phone" type="tel" class="<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" pattern="[0]{1}[8]{1}[0-9]{8,12}" required value="<?php echo e(old('phone') ? old('phone') : (session('success') ? session('success')['calculation']->phone : '')); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.email')); ?></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="email" name="email" type="email" value="<?php echo e(old('email') ? old('email') : (session('success') ? session('success')['calculation']->email : '')); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td class="table-fit label"><?php echo e(__('retirement.income')); ?><span class="red">*</span></td>
                                                <td class="table-fit">:</td>
                                                <td><input id="salary" name="salary" type="number" class="<?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('salary') ? old('salary') : (session('success') ? session('success')['calculation']->salary : '')); ?>"></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-lg-6">
                                        <h6><?php echo e(__('retirement.verification')); ?><span class="red">*</span></h6>
                                        <div class="g-recaptcha" data-sitekey="<?php echo e(config('app.recapcha_key')); ?>"></div>
                                        <div class="invalid-feedback <?php echo e($errors->has('g-recaptcha-response') ? 'd-block' : ''); ?>"><?php echo e($errors->has('g-recaptcha-response') ? $errors->first('g-recaptcha-response') : ''); ?></div>
                                        <button class="btn btn-blue-gradient text-uppercase">Calculate</button>
                                    </div>
                                </div>
                            </form>
                            <div class="result">
                                <h3><?php echo e(__('retirement.max_loan')); ?> Rp. <?php echo e(session('success') ? number_format(session('success')['calculation']->max_loan,2,",",".") : '0,00'); ?></h3>
                                <?php if(session('success')): ?>
                                <p class="text-white m-0"><?php echo e(__('retirement.note')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <h2><?php echo e($post->title); ?></h2>
                            <?php echo $post->description; ?>

                            <hr>
                            <div class="direction">
                                <?php if(isset($post->files[0])): ?>
                                <a href="<?php echo e(asset($post->files[0]->file)); ?>" target="_blank">Download Brochure In PDF</a>
                                <?php else: ?>
                                <div></div>
                                <?php endif; ?>
                                <a href="<?php echo e(generateUrl($menu->slug)); ?>?page=info#info"><i>i</i>&nbsp;&nbsp;&nbsp;More Info</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script>
    $(document).ready(function() {
        $("#location_other").hide();
    });

    $("#location").change(function() {
        if ($(this).val() === 'Other') {
            $("#location_other").show();
            $("#location_other").prop('required', true);
        } else {
            $("#location_other").hide();
            $("#location_other").prop('required', false);
        }
    });

    

    <?php if(count($errors) != 0): ?>
    $(document).ready(function() {
        $('html, body').animate({
            scrollTop: $('#calculation').offset().top
        }, 1000);
    });
    <?php endif; ?>

    <?php if(isset(session('success')['page'])): ?>
    <?php if(session('success')['page'] == 'calculation'): ?>
    $(document).ready(function() {
        $('html, body').animate({
            scrollTop: $('#calculation').offset().top
        }, 1000);
        <?php if(session('success')['calculation']->location_other == 1): ?>
        $("#location_other").show();
                $("#location_other").prop('required', true);
        <?php endif; ?>
    });
    <?php else: ?>
    $(document).ready(function() {
        $('html, body').animate({
            scrollTop: $('#info').offset().top
        }, 1000);
    });
    <?php endif; ?>
    <?php endif; ?>

    <?php if(session('error')): ?>
    $(document).ready(function() {
        $('html, body').animate({
            scrollTop: $('#calculation').offset().top
        }, 1000);
    });
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/program-pensiun/index.blade.php ENDPATH**/ ?>