<div class="main-border">
    <div class="red"></div>
    <div class="blue"></div>
    <div class="action-button">
        <a href="<?php echo e(url('')); ?>">
            <div class="blue-icon">                
                <img src="<?php echo e(asset('assets/img/back.png')); ?>">
            </div>
        </a>
        <a href="javascript:void(0)" onclick="printPage()">
            <div class="red-icon">                
                <img src="<?php echo e(asset('assets/img/print.png')); ?>">
            </div>
        </a>
        <a href="javascript:void(0)" onclick="shareBtn()">
            <div class="blue-icon">                
                <img src="<?php echo e(asset('assets/img/share.png')); ?>">
            </div>
        </a>
    </div>
</div>
<div id="shr"></div><?php /**PATH /home/bankcapi/public_html/system/resources/views/components/action.blade.php ENDPATH**/ ?>