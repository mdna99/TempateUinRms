<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <?php if($parent->parent_id == 0): ?>
    <a href="<?php echo e(route("cp.menu.show",$parent->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php else: ?>
    <a href="<?php echo e(route('cp.menu.submenu.show',[$parent->parent_id,$parent->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php endif; ?>
</div>
<h1>Edit Sub Menu</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.menu.submenu.update', [$parent, $menu])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Konten</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="name" class="col-form-label text-right">Judul</label>
                        <input type="text" id="name" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" autofocus="" value="<?php echo e($menu->title); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="link" class="col-form-label text-right">Deskripsi</label>
                        <textarea rows="3" type="text" id="description" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" autofocus=""><?php echo e($menu->description); ?></textarea>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>                    
                </div>                
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Meta</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="image" class="col-form-label text-right">Cover</label>
                        <div class="mb-2">
                            <img src="<?php echo e(asset($menu->cover)); ?>" class="img-fluid" alt="" id="upload-img-preview">
                            <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Delete Cover Image</a>
                        </div>
                        <div class="custom-file">
                            <input type="file" accept="image/*" name="cover" id="cover" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>">
                            <label class="custom-file-label " for="cover">Choose file</label>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'cover'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <?php if($parent->parent_id == 0): ?>
                    <a href="<?php echo e(route("cp.menu.show",$parent->id)); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('cp.menu.submenu.show',[$parent->parent_id,$parent->id])); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/cp/submenu/edit.blade.php ENDPATH**/ ?>