

<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.permissions.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Detail Permission</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <dl class="meta">  
                    <dt>Nama Role</dt>
                    <dd><?php echo e($role->name); ?></dd>

                    <dt>Permission</dt>
                    <dd>
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Code</th>
                                    <th>Deskripsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($permission->privilegecode->name); ?></td>
                                    <td><?php echo e($permission->privilegecode->description); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </dd>                    
                </dl>
            </div>
            <div class="card-footer bg-whitesmoke">
                <a href="<?php echo e(route('cp.permissions.index')); ?>" class="btn btn-secondary">
                    Kembali
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/permission/show.blade.php ENDPATH**/ ?>