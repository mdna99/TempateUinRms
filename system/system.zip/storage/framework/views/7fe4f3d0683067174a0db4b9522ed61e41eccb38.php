<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.external-apps.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Tambah Aplikasi Eksternal</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.external-apps.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="title">Judul</label>
                        <input type="text" id="title" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" autofocus="" value="<?php echo e(old('title')); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="link">Link</label>
                        <input type="text" id="link" class="form-control<?php echo e($errors->has('link') ? ' is-invalid' : ''); ?>" name="link" autofocus="" value="<?php echo e(old('link')); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'link'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="logo">Logo</label>
                        <br>
                        <div class="mb-2">
                            <img src="" class="w-100" alt="" id="upload-img-preview">
                            <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Delete Logo</a>
                        </div>
                        <div class="custom-file">
                            <input type="file" accept="image/*" name="logo" id="logo" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('logo') ? ' is-invalid' : ''); ?>">
                            <label class="custom-file-label " for="logo">Choose file</label>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'logo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <a href="<?php echo e(route('cp.external-apps.index')); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/external-app/create.blade.php ENDPATH**/ ?>