<?php $__env->startSection('content'); ?>
<div class="container page">
    <div class="about">
        <?php echo $__env->make('components.breadcrumb', [
        'breadcrumbs' => $breadcrumbs
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row highlight">
            <div class="col-lg-6">
                <h1><?php echo e($menu->title); ?></h1>
                <?php echo $menu->description; ?>

            </div>
            <div class="col-lg-6">
                <img class="banner-img" src="<?php echo e(asset($menu->cover)); ?>" alt="<?php echo e($menu->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="sidebar-button d-lg-none">
                    <a href="#" onclick="showTabMenu(event)"><i class="fas fa-bars"></i> <?php echo e(__('menu.tab_menu')); ?></a>
                </div>
                <div class="sidebar">
                    <h3><?php echo e($menu->title); ?></h3>
                    <div class="first">
                        <?php $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(generateUrl($submenu->slug)); ?>"><i class="fas fa-chevron-right"></i> <?php echo e($submenu->title); ?></a>
                        <?php if(isset($submenu->posts)): ?>
                        <div class="second">
                            <?php endif; ?>
                            <?php $__currentLoopData = $submenu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(generateUrl($post->slug)); ?>"><i class="fas fa-chevron-right"></i> <?php echo e($post->title); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($submenu->posts)): ?>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php if(isset($menu->submenus[0]->posts[0])): ?>
            <div class="col-lg-8">
                <div class="content">
                    <h2><?php echo e($menu->submenus[0]->posts[0]->title); ?></h2>
                    <?php if(isset($menu->submenus[0]->posts[0]->cover)): ?>
                    <img src="<?php echo e(asset($menu->submenus[0]->posts[0]->cover)); ?>" alt="<?php echo e($menu->submenus[0]->posts[0]->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';" class="w-100">
                    <?php endif; ?>
                    <?php echo $menu->submenus[0]->posts[0]->description; ?>

                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/templates/menu/about.blade.php ENDPATH**/ ?>