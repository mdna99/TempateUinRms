<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.side-menus.show', $menu)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Edit Menu</h1>
<div class="section-header-breadcrumb">
    <div class="breadcrumb-item"><a href="<?php echo e(url('cp')); ?>">Dashboard</a></div>
    <div class="breadcrumb-item"><a href="<?php echo e(route('cp.side-menus.index')); ?>">Side Menu</a></div>
    <div class="breadcrumb-item"><a href="<?php echo e(route('cp.side-menus.show', $menu)); ?>"><?php echo e($menu->title); ?></a></div>
    <div class="breadcrumb-item active">Edit Menu</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.side-menus.update', $menu)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body p-4">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="id-tab" data-toggle="tab" href="#id" role="tab" aria-controls="id" aria-selected="true">Indonesia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="en-tab" data-toggle="tab" href="#en" role="tab" aria-controls="en" aria-selected="false">English</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="ar-tab" data-toggle="tab" href="#ar" role="tab" aria-controls="ar" aria-selected="false">Arabic</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade active show" id="id" role="tabpanel" aria-labelledby="id-tab">
                            <div class="form-group">
                                <label for="title_id">Judul</label>
                                <input type="text" id="title_id" class="form-control<?php echo e($errors->has('title_id') ? ' is-invalid' : ''); ?>" name="title_id" autofocus="" value="<?php echo e(old('title_id') ? old('title_id') : $menu->translate('id')->title); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_id">Deskripsi</label>
                                <textarea style="height: 100px;" id="description_id" class="form-control<?php echo e($errors->has('description_id') ? ' is-invalid' : ''); ?>" name="description_id" autofocus=""><?php echo e(old('description_id') ? old('description_id') : $menu->translate('id')->description); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="en" role="tabpanel" aria-labelledby="en-tab">
                            <div class="form-group">
                                <label for="title_en">Judul</label>
                                <input type="text" id="title_en" class="form-control" name="title_en" autofocus="" value="<?php echo e(old('title_en') ? old('title_en') : $menu->translate('en')->title); ?>">
                            </div>
                            <div class="form-group">
                                <label for="description_en">Deskripsi</label>
                                <textarea style="height: 100px;" id="description_en" class="form-control<?php echo e($errors->has('description_en') ? ' is-invalid' : ''); ?>" name="description_en" autofocus=""><?php echo e(old('description_en') ? old('description_en') : $menu->translate('en')->description); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="ar" role="tabpanel" aria-labelledby="ar-tab">
                            <div class="form-group">
                                <label for="title_ar">Judul</label>
                                <input dir="rtl" type="text" id="title_ar" class="form-control" name="title_ar" autofocus="" value="<?php echo e(old('title_ar') ? old('title_ar') : $menu->translate('ar')->title); ?>">
                            </div>
                            <div class="form-group">
                                <label for="description_ar">Deskripsi</label>
                                <textarea style="height: 100px;" id="description_ar" class="form-control<?php echo e($errors->has('description_ar') ? ' is-invalid' : ''); ?>" name="description_ar" autofocus=""><?php echo e(old('description_ar') ? old('description_ar') : $menu->translate('ar')->description); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_ar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="form-group<?php echo e($errors->has('is_published') ? ' has-error' : ''); ?>">
                        <label for="is_published">Publishing Status</label>
                        <select id="is_published" name="is_published" class="form-control<?php echo e($errors->has('is_published') ? ' is-invalid' : ''); ?>">
                            <option value="1" <?php echo e(old('is_published') ? (old('is_published') == 1 ? 'selected' : '') : ($menu->is_published == 1 ? 'selected' : '')); ?>>Published</option>
                            <option value="0" <?php echo e(old('is_published') ? (old('is_published') == 0 ? 'selected' : '') : ($menu->is_published == 0 ? 'selected' : '')); ?>>Draft</option>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'is_published'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                        <label for="type">Tipe</label>
                        <select id="type" name="type" class="form-control<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>">
                            <option value="menu" <?php echo e(old('type') ? (old('type') == 'menu' ? 'selected' : '') : ($menu->type == 'menu' ? 'selected' : '')); ?>>Menu</option>
                            <option value="link" <?php echo e(old('type') ? (old('type') == 'link' ? 'selected' : '') : ($menu->type == 'link' ? 'selected' : '')); ?>>Link</option>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'type'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div id="cover" class="form-group">
                        <label for="cover">Cover</label>
                        <img src="<?php echo e(asset($menu->cover)); ?>" class="w-100" alt="" id="upload-img-preview">
                        <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Delete Cover</a>
                        <div class="custom-file mt-2">
                            <input type="file" accept="image/*" name="cover" id="cover" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>">
                            <label class="custom-file-label " for="cover">Choose file</label>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'cover'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div id="template" class="form-group<?php echo e($errors->has('template') ? ' has-error' : ''); ?>">
                        <label for="template">Template Page</label>
                        <select id="template-select" name="template" class="form-control">
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($template); ?>" <?php echo e(old('template') ? (old('template') == $template ? 'selected' : '') : ($menu->template == $template ? 'selected' : '')); ?>><?php echo e($template); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'template'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div id="faculty-detail" style="display: none;">
                        <div class="form-group">
                            <label for="address">Alamat</label>
                            <textarea style="height: auto;" rows="4" id="address" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" autofocus=""><?php echo e(old('address') ? old('address') : $menu->address); ?></textarea>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label for="phone">Telepon</label>
                            <input type="text" id="phone" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" autofocus="" value="<?php echo e(old('phone') ? old('phone') : $menu->phone); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label for="fax">Fax</label>
                            <input type="text" id="fax" class="form-control<?php echo e($errors->has('fax') ? ' is-invalid' : ''); ?>" name="fax" autofocus="" value="<?php echo e(old('fax') ? old('fax') : $menu->fax); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'fax'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" autofocus="" value="<?php echo e(old('email') ? old('email') : $menu->email); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label for="website">Website</label>
                            <input type="text" id="website" class="form-control<?php echo e($errors->has('website') ? ' is-invalid' : ''); ?>" name="website" autofocus="" value="<?php echo e(old('website') ? old('website') : $menu->website); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'website'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group" id="link" style="display: none;">
                        <label for="link">Link</label>
                        <input type="text" id="link" class="form-control<?php echo e($errors->has('link') ? ' is-invalid' : ''); ?>" name="link" autofocus="" value="<?php echo e(old('link') ? old('link') : $menu->link); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'link'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <a href="<?php echo e(route('cp.side-menus.show', $menu)); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    // CKEDITOR.instances['description'].destroy();
    $('.js-upload-image1').change(function(event) {
        makePreview1(this);
        $('#upload-img-preview1').show();
        $('#upload-img-delete1').show();
    });

    function makePreview1(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#upload-img-preview1').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#upload-img-delete1').click(function(event) {
        event.preventDefault();

        $('#upload-img-preview1').attr('src', '').hide();
        $('.custom-file-input1').val(null);
        $(this).hide();
    });

    $(document).ready(function() {
        $('#type').trigger("change");
        $('#template-select').trigger("change");
    });

    document.getElementById("type").onchange = function() {
        var $val = $(this).val();
        var $template = $('#template-select').val();
        if ($val == 'link') {
            $('#link').show();
            $('#cover').hide();
            $('#template').hide();
            $('#faculty-detail').hide();
        } else {
            $('#link').hide();
            $('#cover').show();
            $('#template').show();
            if ($template.substr(15) == 'faculty') {
                $('#faculty-detail').show();
            }
        }
    };

    document.getElementById("template-select").onchange = function() {
        var $val = $(this).val();
        if ($val.substr(15) == 'faculty') {
            $('#faculty-detail').show();
        } else {
            $('#faculty-detail').hide();
        }
    };
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/side-menu/edit.blade.php ENDPATH**/ ?>