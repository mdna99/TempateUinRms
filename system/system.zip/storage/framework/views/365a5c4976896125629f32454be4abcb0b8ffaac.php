<?php if($errors->has($field)): ?>

	<span class="invalid-feedback d-block">
        <strong><?php echo e($errors->first($field)); ?></strong>
    </span>

<?php endif; ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/components/form-error.blade.php ENDPATH**/ ?>