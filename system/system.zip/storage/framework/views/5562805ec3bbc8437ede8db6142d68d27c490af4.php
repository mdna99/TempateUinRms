

<?php $__env->startSection('title', 'Kontak Kami'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body p-0">
                <table class="table table-striped table-md">
                    <thead>
                        <tr>
                            <th class="table-fit">#</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th class="table-fit">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $rowNumber = ($contacts->currentpage()-1) * $contacts->perpage() + 1;
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($rowNumber++); ?></td>
                                <td><?php echo e($contact->name); ?></td>
                                <td><?php echo e($contact->email); ?></td>
                                <td class="table-fit"><?php echo e($contact->created_at->format('d F Y    ')); ?></td>
                                <td class="table-fit"><?php echo e($contact->created_at->format('H:i')); ?></td>
                                <td class="table-fit">
                                    <form id="form-action" method="POST" action="<?php echo e(route('cp.contacts.destroy', $contact)); ?>" accept-charset="UTF-8">
                                        <input name="_method" type="hidden" value="DELETE">
                                        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">

                                        <div class="table-links">
                                            <a href="<?php echo e(route('cp.contacts.show', $contact)); ?>">Detail</a>
                                            <div class="bullet"></div>
                                             <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Anda yakin akan menghapus data ?');">
                                                Delete
                                            </button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo e($contacts->links('cp.pagination.default')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/contact/index.blade.php ENDPATH**/ ?>