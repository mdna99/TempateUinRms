<?php $__env->startSection('title'); ?>
    <div class="section-header-back">
      <a href="<?php echo e(route('cp.exchanges.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    </div>
    <h1>Add Rate</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.rates.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Content</h4>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="name" class="col-sm-3 col-form-label text-right">Name</label>
                        <div class="col-sm-6">
                            <input type="text" id="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" autofocus="" value="<?php echo e(old('name')); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>                    
                </div>
                <div class="card-footer bg-whitesmoke">
                    <div class="col-sm-6 offset-sm-3">
                        <button type="submit" class="btn btn-primary">
                            Save
                        </button>
                        <a href="<?php echo e(route('cp.exchanges.index')); ?>" class="btn btn-secondary">
                            Cancel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/cp/rate/create.blade.php ENDPATH**/ ?>