

<?php $__currentLoopData = $main_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="nav-item <?php echo e($menu->id == 4 ? '' : 'dropdown'); ?> <?php echo e($loop->iteration < 3 ? 'right-position' : 'left-position'); ?>">
    <a href="<?php echo e($menu->id == 4 ? generateUrl($menu->slug) : '#'); ?>" <?php echo e($menu->id == 4 ? '' : 'data-toggle=dropdown'); ?> class="nav-link"><?php echo e($menu->title); ?></a>
    <?php if($menu->id != 4): ?>
    <ul class="dropdown-menu">
        <div class="caret-up"></div>
        <?php $__currentLoopData = $menu->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li <?php if($submenu->id < 8 || $submenu->id > 11): ?> <?php echo e('class=dropdown-submenu'); ?> <?php endif; ?>>
            <a href="<?php if($submenu->id < 8 || $submenu->id > 11): ?> <?php echo e('#'); ?> <?php else: ?> <?php echo e(generateUrl($submenu->slug)); ?> <?php endif; ?>" <?php if($submenu->id < 8 || $submenu->id > 11): ?> <?php echo e('data-toggle=dropdown'); ?> <?php endif; ?> class="dropdown-item <?php if($submenu->id < 8 || $submenu->id > 11): ?> <?php echo e('submenu-title'); ?> <?php endif; ?>">
                <?php echo e($submenu->title); ?>

            </a>
            <?php if($submenu->id < 8 || $submenu->id > 11): ?>
            <ul class="dropdown-menu">
                <?php $__currentLoopData = $submenu->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li <?php if($submenu1->id < 8 || $submenu1->id > 11): ?> <?php echo e('class=dropdown-submenu'); ?> <?php endif; ?>>
                    <a href="<?php if($submenu1->id < 8 || $submenu1->id > 11): ?> <?php echo e('#'); ?> <?php else: ?> <?php echo e(generateUrl($submenu1->slug)); ?> <?php endif; ?>" <?php if($submenu1->id < 8 || $submenu1->id > 11): ?> <?php echo e('data-toggle=dropdown'); ?> <?php endif; ?> class="dropdown-item <?php if($submenu1->id < 8 || $submenu1->id > 11): ?> <?php echo e('submenu-title'); ?> <?php endif; ?>">
                        <?php echo e($submenu1->title); ?>

                    </a>
                    <?php if($submenu1->id < 8 || $submenu1->id > 11): ?>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $submenu1->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li <?php if($submenu2->id < 8 || $submenu2->id > 11): ?> <?php echo e('class=dropdown-submenu'); ?> <?php endif; ?>>
                            <a href="<?php if($submenu2->id < 8 || $submenu2->id > 11): ?> <?php echo e('#'); ?> <?php else: ?> <?php echo e(generateUrl($submenu2->slug)); ?> <?php endif; ?>" <?php if($submenu2->id < 8 || $submenu2->id > 11): ?> <?php echo e('data-toggle=dropdown'); ?> <?php endif; ?> class="dropdown-item <?php if($submenu2->id < 8 || $submenu2->id > 11): ?> <?php echo e('submenu-title'); ?> <?php endif; ?>">
                                <?php echo e($submenu2->title); ?>

                            </a>
                            <?php if($submenu2->id < 8 || $submenu2->id > 11): ?>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $submenu2->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(generateUrl($submenu3->slug)); ?>" class="dropdown-item">
                                    <?php echo e($submenu3->title); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $submenu2->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(generateUrl($post->slug)); ?>" class="dropdown-item">
                                    <?php echo e($post->title); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $submenu1->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(generateUrl($post->slug)); ?>" class="dropdown-item">
                            <?php echo e($post->title); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $submenu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(generateUrl($post->slug)); ?>" class="dropdown-item">
                    <?php echo e($post->title); ?>

                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $menu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(generateUrl($post->slug)); ?>" class="dropdown-item">
                <?php echo e($post->title); ?>

            </a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/bankcapi/public_html/dev/system/resources/views/components/menu.blade.php ENDPATH**/ ?>