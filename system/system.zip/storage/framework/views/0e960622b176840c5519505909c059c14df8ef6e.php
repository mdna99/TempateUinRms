<?php $__env->startSection('content'); ?>
<div class="home-slider owl-carousel owl-theme">
    <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if(isset($slider->link)): ?>
    <a href="<?php echo e($slider->link); ?>" target="_blank">
        <?php endif; ?>
        <img src="<?php echo e(asset($slider->image)); ?>" alt="<?php echo e($slider->caption); ?>">
        <?php if(isset($slider->link)): ?>
    </a>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>    
    <img src="<?php echo e(asset('assets/img/slider.JPG')); ?>" alt="Bank Capital">
    <?php endif; ?>
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid" id="print-area">
    <div class="row">
        <div class="col-md-7 col-lg-5">
            <div class="home-table">
                <div class="exchange-rate">
                    <p class="title">EXCHANGE RATE</p>
                    <?php if($exchange_rate->isNotEmpty()): ?>
                    <p class="date"><?php echo e($exchange_rate->toArray()[0]['created_at']); ?></p>
                    <?php elseif($latest_exchange_rate->isNotEmpty()): ?>
                    <p class="date"><?php echo e($latest_exchange_rate->toArray()[0]['updated_at'] ? $latest_exchange_rate->toArray()[0]['updated_at'] : $latest_exchange_rate->toArray()[0]['created_at']); ?></p>
                    <?php else: ?>
                    <p>No data</p>
                    <?php endif; ?>
                    <?php if($exchange_rate->isNotEmpty() || $latest_exchange_rate->isNotEmpty()): ?>
                    <table>
                        <thead>                            
                            <tr>
                                <th>Rates</th>
                                <th><?php echo e(__('homepage.beli')); ?></th>
                                <th><?php echo e(__('homepage.jual')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $exchange_rate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($exchange->rate->name); ?></strong></td>
                                <td><?php echo e(number_format($exchange->buy, 2, '.', ',')); ?></td>
                                <td><?php echo e(number_format($exchange->sell, 2, '.', ',')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php $__currentLoopData = $latest_exchange_rate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($exchange->rate->name); ?></strong></td>
                                <td><?php echo e(number_format($exchange->buy, 2, '.', ',')); ?></td>
                                <td><?php echo e(number_format($exchange->sell, 2, '.', ',')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>                                                  
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                <div class="capital-depo">
                    <p class="title">CAPITAL DEPO - RUPIAH</p>
                    <div class="minimum">                        
                        <p class="title"><?php echo e(__('homepage.simpanan_minimum')); ?></p>
                        <p class="nominal">IDR <?php echo e(number_format($minimum_deposit->value, 0, ',', '.')); ?></p>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th colspan="2"><?php echo e(__('homepage.suku_bunga')); ?></th>
                            </tr>
                        </thead>
                        <tbody>  
                            <tr>
                                <td><strong><?php echo e(__('homepage.periode')); ?></strong></td>
                                <td>%</td>
                            </tr>
                            <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($term->key.' '.__('homepage.bulan')); ?><?php echo e(app()->getLocale() == 'en' && $term->key > 1 ? 's' : ''); ?></strong></td>
                                <td><?php echo e(number_format($term->value, 2)); ?> %</td>
                            </tr>                        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-5 col-lg-7">
            <div class="internet-banking">
                <img src="<?php echo e(asset(data_get($setting, 'internet_banking_cover', '-'))); ?>">
                <div class="detail">
                    <h2><?php echo e(__('homepage.internet_banking_title')); ?></h2>
                    <p><?php echo e(__('homepage.internet_banking_description')); ?></p>
                    <a href="<?php echo e(data_get($setting, 'internet_banking_link', '#')); ?>" class="btn btn-white" target="_blank">LOG-IN</a>
                </div>
            </div>
        </div>
    </div>
    <div class="mobile-application">
        <h1><?php echo e(__('homepage.mbanking_title')); ?></h1>
        <div class="content">
            <div class="description">
                <img src="<?php echo e(asset('assets/img/mbanking.png')); ?>">
                <h2><?php echo e(__('homepage.mbanking_description')); ?></h2>
            </div>
            <div class="download">
                <h2><?php echo e(__('homepage.mbanking_download')); ?></h2>
                <a href="<?php echo e(data_get($setting, 'mobile_banking_link', '#')); ?>" target="_blank">
                    <img src="<?php echo e(asset('assets/img/gplay.png')); ?>">
                </a>
            </div>
        </div>
    </div>
    <div class="row">
        <?php if($featured_product): ?>
        <div class="col-lg-6">
            <div class="featured-product">
                <div class="title">
                    <h1><?php echo e(__('homepage.fitur_produk')); ?></h1>
                </div>
                <div class="item">
                    <a href="<?php echo e(generateUrl($featured_product->slug)); ?>">
                        <img src="<?php echo e(asset($featured_product->thumbnail)); ?>" onerror="this.src='<?php echo e(asset('assets/img/nocover.png')); ?>'">
                        <div class="overlay">
                            <h2><?php echo e($featured_product->title); ?></h2>
                            <p>Detail...</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if($latest_news->isNotEmpty()): ?>
        <div class="col-lg-6">
            <div class="capital-news">
                <div class="title">
                    <h1><?php echo e(__('homepage.berita_capital')); ?></h1>
                </div>
                <?php $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">  
                    <div class="image">  
                        <img src="<?php echo e(asset($news->thumbnail)); ?>" onerror="this.src='<?php echo e(asset('assets/img/nocover.png')); ?>'">
                    </div>
                    <div class="content">
                        
                        <a href="<?php echo e(generateUrl($news->slug)); ?>">
                            <h2 class="title">
                                <?php echo e($news->title); ?>

                            </h2>
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php if(count($running_texts) != 0): ?>
<div class="running-text">
    <div class="marquee">
        <span>
            <p>NEWS:</p>
            <?php $__currentLoopData = $running_texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $running_text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e(date('d-m-Y', strtotime($running_text->created_at))); ?> <a href="<?php echo e(generateUrl($running_text->slug)); ?>"><?php echo e($running_text->title); ?></a></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </span>         
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/index.blade.php ENDPATH**/ ?>