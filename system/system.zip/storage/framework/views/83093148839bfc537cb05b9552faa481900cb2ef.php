<?php if(isset($post)): ?>
<?php
$title = $post->title;
$description = Str::limit(strip_tags($post->description), 200);
$image = !empty($post->thumbnail) ? asset($post->thumbnail) : asset('assets/img/nocover.png');
$url = generateUrl($post->slug);
?>
<?php elseif(isset($menu)): ?>
<?php
$title = $menu->title;
$description = Str::limit(strip_tags($menu->description), 200);
$image = !empty($menu->cover) ? asset($menu->cover) : asset('assets/img/nocover.png');
$url = generateUrl($menu->slug);
?>
<?php else: ?>
<?php
$title = data_get($setting, 'name', '-');
$description = strip_tags(data_get($setting, 'tagline', '-'));
$image = asset(data_get($setting, 'icon', '-'));
$url = generateUrl('');
?>
<?php endif; ?>

        <meta name="description" content="<?php echo e(strip_tags(data_get($setting, 'tagline', '-'))); ?>"/>
        <meta name="author" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />
        <meta name="copyright" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />
        <meta name="application-name" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />

        <meta property="og:title" content="<?php echo e($title); ?>" />
        <meta property="og:type" content="article" />
        <meta property="og:image" content="<?php echo e($image); ?>" />
        <meta property="og:image:alt" content="<?php echo e($title); ?>" />
        <meta property="og:image:width" content="500" />
        <meta property="og:image:height" content="500" />
        <meta property="og:url" content="<?php echo e($url); ?>" />
        <meta property="og:description" content="<?php echo e($description); ?>" />

        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content="<?php echo e($title); ?>" />
        <meta name="twitter:description" content="<?php echo e($description); ?>" />
        <meta name="twitter:image" content="<?php echo e($image); ?>" /><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/components/meta.blade.php ENDPATH**/ ?>