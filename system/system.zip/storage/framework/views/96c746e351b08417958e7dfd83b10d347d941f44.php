<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <?php if($menu->parent_id == 0): ?>
    <a href="<?php echo e(route('cp.main-menus.show',$menu->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php else: ?>
    <a href="<?php echo e(route('cp.main-menus.submenus.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php endif; ?>
</div>
<h1>Tambah Post</h1>
<div class="section-header-breadcrumb">
    <?php if(count($breadcrumbs) > 2): ?>
    <div class="breadcrumb-item"><a href="<?php echo e(url('cp')); ?>">...</a></div>
    <?php else: ?>
    <div class="breadcrumb-item"><a href="<?php echo e(url('cp')); ?>">Dashboard</a></div>
    <div class="breadcrumb-item"><a href="<?php echo e(route('cp.main-menus.index')); ?>">Main Menu</a></div>
    <?php endif; ?>
    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="breadcrumb-item"><a href="<?php echo e($breadcrumb->parent_id == 0 ? route('cp.main-menus.show', $breadcrumb->id) : route('cp.main-menus.submenus.show', [$breadcrumb->parent_id, $breadcrumb->id])); ?>"><?php echo e($breadcrumb->title); ?></a></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="breadcrumb-item active">Tambah Post</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.main-menus.posts.store', $menu)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body p-4">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="id-tab" data-toggle="tab" href="#id" role="tab" aria-controls="id" aria-selected="true">Indonesia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="en-tab" data-toggle="tab" href="#en" role="tab" aria-controls="en" aria-selected="false">English</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="ar-tab" data-toggle="tab" href="#ar" role="tab" aria-controls="ar" aria-selected="false">Arabic</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="id" role="tabpanel" aria-labelledby="id-tab">
                            <div class="form-group">
                                <label for="title_id" class="col-form-label text-right">Judul</label>
                                <input type="text" id="title_id" class="form-control<?php echo e($errors->has('title_id') ? ' is-invalid' : ''); ?>" name="title_id" autofocus="" value="<?php echo e(old('title_id')); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_id" class="col-form-label text-right">Deskripsi</label>
                                <textarea rows="4" type="text" id="description_id" class="form-control<?php echo e($errors->has('description_id') ? ' is-invalid' : ''); ?>" name="description_id" autofocus="" style="height: auto"><?php echo e(old('description_id')); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="en" role="tabpanel" aria-labelledby="en-tab">
                            <div class="form-group">
                                <label for="title_en" class="col-form-label text-right">Judul</label>
                                <input type="text" id="title_en" class="form-control<?php echo e($errors->has('title_en') ? ' is-invalid' : ''); ?>" name="title_en" autofocus="" value="<?php echo e(old('title_en')); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_en" class="col-form-label text-right">Deskripsi</label>
                                <textarea rows="4" type="text" id="description_en" class="form-control<?php echo e($errors->has('description_en') ? ' is-invalid' : ''); ?>" name="description_en" autofocus="" style="height: auto"><?php echo e(old('description_en')); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="ar" role="tabpanel" aria-labelledby="ar-tab">
                            <div class="form-group">
                                <label for="title_ar" class="col-form-label text-right">Judul</label>
                                <input dir='rtl' type="text" id="title_ar" class="form-control<?php echo e($errors->has('title_ar') ? ' is-invalid' : ''); ?>" name="title_ar" autofocus="" value="<?php echo e(old('title_ar')); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_ar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_ar" class="col-form-label text-right">Deskripsi</label>
                                <textarea rows="4" type="text" id="description_ar" class="form-control<?php echo e($errors->has('description_ar') ? ' is-invalid' : ''); ?>" name="description_ar" autofocus="" style="height: auto"><?php echo e(old('description_ar')); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_ar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <!-- <div class="form-group">
                        <label class="custom-switch p-0">
                            <input type="checkbox" name="is_running_text" class="custom-switch-input">
                            <span class="custom-switch-indicator"></span>
                            <span class="custom-switch-description">Set as running text</span>
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="custom-switch p-0">
                            <input type="checkbox" name="is_featured_product" class="custom-switch-input">
                            <span class="custom-switch-indicator"></span>
                            <span class="custom-switch-description">Set as featured product in homepage</span>
                        </label>
                    </div> -->
                    <div class="form-group<?php echo e($errors->has('is_published') ? ' has-error' : ''); ?>">
                        <label for="is_published">Publishing Status</label>
                        <select id="is_published" name="is_published" class="form-control">
                            <option value="1" <?php echo e(old('is_published') == 1 ? 'selected' : ''); ?>>Published</option>
                            <option value="0" <?php echo e(old('is_published') == 0 ? 'selected' : ''); ?>>Draft</option>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'is_published'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="created_at" class="col-form-label text-right">Tanggal Post</label>
                        <input type="date" id="created_at" class="form-control<?php echo e($errors->has('created_at') ? ' is-invalid' : ''); ?>" name="created_at" autofocus="" value="<?php echo e(old('created_at') ? old('created_at') : date('Y-m-d')); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label>Cover Image</label>
                        <div class="mb-2">
                            <img src="" class="img-fluid" alt="" id="upload-img-preview" style="display: none;">
                            <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Delete Cover Image</a>
                        </div>
                        <div class="custom-file">
                            <input type="file" accept="image/*" name="cover" id="cover" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>">
                            <label class="custom-file-label " for="cover">Choose file</label>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'cover'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('template') ? ' has-error' : ''); ?>">
                        <label for="template">Template Page</label>
                        <select name="template" class="form-control">
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($template); ?>" <?php echo e($template == old('template') ? 'selected' : ($template == 'templates.post.default' ? 'selected' : '')); ?>><?php echo e($template); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'template'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="external_link" class="col-form-label text-right">Link Eksternal</label>
                        <input type="text" id="external_link" class="form-control<?php echo e($errors->has('external_link') ? ' is-invalid' : ''); ?>" name="external_link" autofocus="" value="<?php echo e(old('external_link')); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'external_link'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Files</h4>
                    <div class="card-header-action">
                        <button class="btn btn-primary tambah-file">
                            Add File
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Title</th>
                                <th scope="col">File</th>
                                <th scope="col" class="table-fit">Action</th>
                            </tr>
                        </thead>
                        <tbody id="body-table">

                        </tbody>
                    </table>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <?php if($menu->parent_id == 0): ?>
                    <a href="<?php echo e(route('cp.main-menus.show',$menu->id)); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('cp.main-menus.submenus.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="d-none">
    <table>
        <tbody id="table-row">
            <tr>
                <td>
                    <input type="text" class="form-control" id="title_files" name="title_files[]" required="">
                </td>
                <td>
                    <input type="file" class="form-control" name="files[]" required="">
                </td>
                <td>
                    <button class="btn btn-danger hapus-file" type="button"><i class="fa fa-trash"></i></button>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $('.js-upload-image1').change(function(event) {
        makePreview1(this);
        $('#upload-img-preview1').show();
        $('#upload-img-delete1').show();
    });

    function makePreview1(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#upload-img-preview1').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#upload-img-delete1').click(function(event) {
        event.preventDefault();

        $('#upload-img-preview1').attr('src', '').hide();
        $('.custom-file-input1').val(null);
        $(this).hide();
    });

    $('body').on('click', '.tambah-file', function(event) {
        event.preventDefault();

        var template = $('#table-row').html();
        $('#body-table').append(template);
    });
    $('body').on('click', '.hapus-file', function(event) {
        event.preventDefault();

        var tableParent = $(this).closest('table');
        var trParent = $(this).closest('tr');
        trParent.remove();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/main-menu/post/create.blade.php ENDPATH**/ ?>