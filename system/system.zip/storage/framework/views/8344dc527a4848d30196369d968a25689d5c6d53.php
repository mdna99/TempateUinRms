<?php $__env->startSection('content'); ?>
<video class="video" muted="muted" autoplay="" loop="">
    <source src="<?php echo e(asset(data_get($setting, 'video', '-'))); ?>" type="video/webm">
</video>
<div class="container home">
    <?php if(count($latestnews) != 0): ?>
    <div class="latest-news">
        <div class="row">
            <?php $__currentLoopData = $latestnews->chunk(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loop->parent->first): ?>
            <div class="col-md-5">
                <img class="latest-img" src="<?php echo e(asset($item->cover)); ?>" alt="<?php echo e($item->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
            </div>
            <div class="col-md-7">
                <h1><?php echo e(__('homepage.latest_news')); ?></h1>
                <div class="latest">
                    <h3><?php echo e($item->formatted_published_at); ?></h3>
                    <h2><?php echo e($item->title); ?></h2>
                    <p><?php echo e(Str::limit(strip_tags($item->description), 450)); ?></p>
                    <a href="<?php echo e(generateUrl($item->slug)); ?>"><?php echo e(__('homepage.read_more')); ?></a>
                </div>
            </div>
            <?php else: ?>
            <div class="col-md-4">
                <div class="item">
                    <img src="<?php echo e(asset($item->cover)); ?>" alt="<?php echo e($item->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
                    <div class="content">
                        <h3><?php echo e($item->formatted_published_at); ?></h3>
                        <h2><?php echo e($item->title); ?></h2>
                        <a href="<?php echo e(generateUrl($item->slug)); ?>"><?php echo e(__('homepage.read_more')); ?></a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="w-100 text-center">
            <a href="<?php echo e(generateUrl($latestnews[0]->menu->slug)); ?>" class="btn btn-black"><?php echo e(__('homepage.more_news')); ?></a>
        </div>
    </div>
    <?php endif; ?>
    <?php if($education): ?>
    <div class="education">
        <div class="row">
            <div class="col-md-5">
                <img class="highlight-img" src="<?php echo e(asset($education->cover)); ?>" alt="<?php echo e($education->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
            </div>
            <div class="col-md-7">
                <h1><?php echo e($education->title); ?></h1>
                <div class="highlight">
                    <p><?php echo e(Str::limit(strip_tags($education->description), 450)); ?></p>
                    <a href="<?php echo e(generateUrl($education->slug)); ?>" class="btn btn-black"><?php echo e(__('homepage.more')); ?></a>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="item-faculty">
                    <img src="<?php echo e(asset($faculty->cover)); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';" class="w-100">
                    <div class="title">
                        <a href="<?php echo e(generateUrl($faculty->slug)); ?>"><?php echo e($faculty->title); ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
    <?php endif; ?>
    <?php if(count($homemenus) != 0): ?>
    <?php $__currentLoopData = $homemenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $homemenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key == 0): ?>
    <div class="research">
        <div class="row">
            <div class="col-md-7">
                <h1><?php echo e($homemenu->title); ?></h1>
                <p><?php echo e(Str::limit(strip_tags($homemenu->description), 450)); ?></p>
                <a href="<?php echo e(generateUrl($homemenu->slug)); ?>" class="btn btn-black"><?php echo e(__('homepage.more')); ?></a>
            </div>
            <div class="col-md-5">
                <img src="<?php echo e(asset($homemenu->cover)); ?>" alt="<?php echo e($homemenu->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
            </div>
        </div>
    </div>
    <?php elseif($key == 1): ?>
    <div class="service">
        <div class="row">
            <div class="col-md-5">
                <img src="<?php echo e(asset($homemenu->cover)); ?>" alt="<?php echo e($homemenu->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
            </div>
            <div class="col-md-7">
                <h1><?php echo e($homemenu->title); ?></h1>
                <p><?php echo e(Str::limit(strip_tags($homemenu->description), 450)); ?></p>
                <a href="<?php echo e(generateUrl($homemenu->slug)); ?>" class="btn btn-black"><?php echo e(__('homepage.more')); ?></a>
            </div>
        </div>
    </div>
    <?php elseif($key == 2): ?>
    <div class="post">
        <div class="row">
            <?php if(isset($homemenu->posts[0])): ?>
            <div class="col-md-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h2><?php echo e($homemenu->title); ?></h2>
                    <a href="<?php echo e(generateUrl($homemenu->slug)); ?>"><?php echo e(__('homepage.other')); ?> <i class="fas fa-chevron-right"></i></a>
                </div>
                <div class="item shadow">
                    <img src="<?php echo e(asset($homemenu->posts[0]->cover)); ?>" alt="<?php echo e($homemenu->posts[0]->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
                    <div class="text">
                        <h3><?php echo e($homemenu->posts[0]->title); ?></h3>
                    </div>
                    <a href="<?php echo e(generateUrl($homemenu->posts[0]->slug)); ?>"><?php echo e(__('homepage.read_more')); ?></a>
                </div>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <?php if(isset($homemenu->posts[0])): ?>
            <div class="col-md-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h2><?php echo e($homemenu->title); ?></h2>
                    <a href="<?php echo e(generateUrl($homemenu->slug)); ?>"><?php echo e(__('homepage.other')); ?> <i class="fas fa-chevron-right"></i></a>
                </div>
                <div class="item shadow">
                    <img src="<?php echo e(asset($homemenu->posts[0]->cover)); ?>" alt="<?php echo e($homemenu->posts[0]->title); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
                    <div class="text">
                        <h3><?php echo e($homemenu->posts[0]->title); ?></h3>
                    </div>
                    <a href="<?php echo e(generateUrl($homemenu->posts[0]->slug)); ?>"><?php echo e(__('homepage.read_more')); ?></a>
                </div>
            </div>
            <?php endif; ?>
    <?php endif; ?>
    <?php if($loop->last && count($homemenus) > 2): ?>
        </div>
        </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/index.blade.php ENDPATH**/ ?>