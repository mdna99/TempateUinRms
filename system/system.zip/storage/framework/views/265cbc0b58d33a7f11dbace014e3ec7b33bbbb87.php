<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
    <?php if(App::environment('local')): ?>
    <!--To prevent most search engine web crawlers from indexing a page on your site-->
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    <?php endif; ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo e(data_get($setting, 'name', '-')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css?ver=' . strtotime(date('Y-m-d H:i:s')))); ?>">
    <?php echo $__env->make('components.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="navbar-second">
        <div class="link-container">
            <?php $__currentLoopData = $sidemenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidemenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="link" href="<?php echo e(generateUrl($sidemenu->slug)); ?>"><?php echo e($sidemenu->title); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="dropdown">
            <button class="btn dropdown-toggle" type="button" id="languange" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="d-flex align-items-center">
                    <?php if(app()->getLocale() == 'id'): ?>
                    <img src="<?php echo e(asset('assets/id.png')); ?>" style="width: 20px; margin-right: 5px">Indonesia
                    <?php elseif(app()->getLocale() == 'en'): ?>
                    <img src="<?php echo e(asset('assets/en.png')); ?>" style="width: 20px; margin-right: 5px">English
                    <?php else: ?>
                    <img src="<?php echo e(asset('assets/ar.png')); ?>" style="width: 20px; margin-right: 5px">Arabic
                    <?php endif; ?>
                </div>
            </button>
            <div class="dropdown-menu" aria-labelledby="languange">
                <a class="dropdown-item" href="<?php echo e(url('id')); ?>"><img src="<?php echo e(asset('assets/id.png')); ?>"> Indonesia</a>
                <a class="dropdown-item" href="<?php echo e(url('en')); ?>"><img src="<?php echo e(asset('assets/en.png')); ?>"> English</a>
                <a class="dropdown-item" href="<?php echo e(url('ar')); ?>"><img src="<?php echo e(asset('assets/ar.png')); ?>"> Arabic</a>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-main">
        <div class="top">
            <a class="navbar-brand shadow" href="<?php echo e(url('')); ?>">
                <img src="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>" alt="<?php echo e(data_get($setting, 'name', '-')); ?>">
            </a>
        </div>
        <div class="scroll d-none">
            <a class="navbar-brand" href="<?php echo e(url('')); ?>">
                <img src="<?php echo e(asset(data_get($setting, 'logo', '-'))); ?>" alt="<?php echo e(data_get($setting, 'name', '-')); ?>">
            </a>
        </div>
        <div class="d-flex" style="padding: 11px 0;">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-main" aria-controls="navbar-main" aria-expanded="false" aria-label="Toggle navigation" onclick="closeNavbarSecond()">
                <i class="fas fa-bars"></i>
            </button>
            <button class="btn text-white navbar-second-toggler" onclick="openNavbarSecond()">
                <i class="fas fa-ellipsis-v"></i>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="navbar-main">
            <ul class="navbar-nav">
                <?php $__currentLoopData = $mainmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e($mainmenu->type == 'menu' ? generateUrl($mainmenu->slug) : $menu->link); ?>"><?php echo e($mainmenu->title); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <form action="<?php echo e(generateUrl(trans('route.search'))); ?>" method="GET" accept-charset="utf-8" class="form-inline">
                <input class="form-control search-input" type="search" name="keyword" placeholder="<?php echo e(__('search.placeholder')); ?>" aria-label="Search" value="<?php echo e(request('keyword')); ?>">
                <i class="fas fa-search search-icon"></i>
            </form>
        </div>
    </nav>
    <div class="mt-87"></div>

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <div class="container-fluid">
            <div class="row footer">
                <div class="col-md-3 mb-4">
                    <div class="img">
                        <img src="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>" class="shadow">
                    </div>
                    <p class="address"><?php echo e(data_get($setting, 'address', '-')); ?></p>
                    <div class="d-flex flex-column">
                        <a href="tel:<?php echo e(data_get($setting, 'phone', '-')); ?>"><i class="fas fa-phone"></i> <?php echo e(data_get($setting, 'phone', '-')); ?></a>
                        <a href="fax:<?php echo e(data_get($setting, 'fax', '-')); ?>"><i class="fas fa-fax"></i> <?php echo e(data_get($setting, 'fax', '-')); ?></a>
                        <a href="mailto:<?php echo e(data_get($setting, 'email', '-')); ?>"><i class="far fa-envelope"></i> <?php echo e(data_get($setting, 'email', '-')); ?></a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="row">
                        <?php $__currentLoopData = $footer_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-3 mb-4">
                            <h3><?php echo e($item->title); ?></h3>
                            <?php if(isset($item->submenus)): ?>
                            <div class="d-flex flex-column">
                                <?php $__currentLoopData = $item->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="mb-2" href="<?php echo e($submenu->website); ?>"><?php echo e($submenu->title); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                            <?php if(isset($item->posts)): ?>
                            <div class="d-flex flex-column">
                                <?php $__currentLoopData = $item->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="mb-1" href="<?php echo e(generateUrl($post->slug)); ?>"><?php echo e($post->title); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-3 mb-2">
                            <h3><?php echo e(__('footer.follow_us')); ?></h3>
                            <div class="d-flex flex-column">
                                <?php $__currentLoopData = $social_media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="mb-1" href="<?php echo e($sm->link); ?>"><i class="<?php echo e($sm->icon); ?>"></i> <?php echo e($sm->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <p class="copyright">© <?php echo e(date('Y')); ?> <?php echo e(data_get($setting, 'name', '-')); ?></p>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js" data-cover></script>
    <script type="text/javascript" src="<?php echo e(asset('js/script.js?ver=' . strtotime(date('Y-m-d H:i:s')))); ?>"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/layouts/base.blade.php ENDPATH**/ ?>