<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="faculty-detail">
        <?php echo $__env->make('components.breadcrumb', [
        'breadcrumbs' => $breadcrumbs
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row highlight">
            <div class="col-lg-6">
                <h1><?php echo e($menu->title); ?></h1>
                <?php echo $menu->description; ?>

            </div>
            <div class="col-lg-6">
                <img class="banner-img w-100" src="<?php echo e(asset($menu->cover)); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
                <div class="detail">
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td class="table-fit"><?php echo e(__('faculty.address')); ?></td>
                            <td class="table-fit">:</td>
                            <td><?php echo e($menu->address); ?></td>
                        </tr>
                        <tr>
                            <td class="table-fit"><?php echo e(__('faculty.phone')); ?></td>
                            <td class="table-fit">:</td>
                            <td><?php echo e($menu->phone); ?></td>
                        </tr>
                        <tr>
                            <td class="table-fit"><?php echo e(__('faculty.fax')); ?></td>
                            <td class="table-fit">:</td>
                            <td><?php echo e($menu->fax); ?></td>
                        </tr>
                        <tr>
                            <td class="table-fit"><?php echo e(__('faculty.email')); ?></td>
                            <td class="table-fit">:</td>
                            <td><?php echo e($menu->email); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('faculty.website')); ?></td>
                            <td>:</td>
                            <td><?php echo e($menu->website); ?></td>
                        </tr>
                    </table>
                    <a href="http://<?php echo e($menu->website); ?>" class="btn btn-black"><?php echo e(__('faculty.visit_website')); ?></a>
                </div>
            </div>
        </div>
        <?php if(count($menu->posts) != 0): ?>
        <div class="major">
            <h2>Program Studi</h2>
            <div class="row">
                <?php $__currentLoopData = $menu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="item">
                        <img src="<?php echo e(asset($post->cover)); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';" class="w-100">
                        <div class="content">
                            <a href="<?php echo e(generateUrl($post->slug)); ?>"><?php echo e($post->title); ?></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/templates/menu/faculty.blade.php ENDPATH**/ ?>