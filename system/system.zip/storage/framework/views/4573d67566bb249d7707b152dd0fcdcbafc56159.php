

<?php $__env->startSection('title'); ?>
    <div class="section-header-back">
      <a href="<?php echo e(route('cp.menus.posts.edit', [3,3])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    </div>
    <h1>Edit Area</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.locations.update', $location)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Content</h4>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="name" class="col-sm-3 col-form-label text-right">Area</label>
                        <div class="col-sm-6">
                            <select name="area_id" class="form-control">
                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($area->id); ?>" <?php echo e($location->area_id == $area->id ? 'selected' : ''); ?>><?php echo e($area->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'area_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div> 
                    <div class="form-group row">
                        <label for="unit" class="col-sm-3 col-form-label text-right">Unit</label>
                        <div class="col-sm-6">
                            <input type="text" id="unit" class="form-control<?php echo e($errors->has('unit') ? ' is-invalid' : ''); ?>" name="unit" autofocus="" value="<?php echo e($location->unit); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'unit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="address" class="col-sm-3 col-form-label text-right">Address</label>
                        <div class="col-sm-6">
                            <textarea rows="4" type="text" id="address" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" autofocus=""><?php echo e($location->address); ?></textarea>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>                    
                    <div class="form-group row">
                        <label for="phone" class="col-sm-3 col-form-label text-right">Phone</label>
                        <div class="col-sm-6">
                            <input type="text" id="phone" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" autofocus="" value="<?php echo e($location->phone); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>                    
                    <div class="form-group row">
                        <label for="fax" class="col-sm-3 col-form-label text-right">Fax</label>
                        <div class="col-sm-6">
                            <input type="text" id="fax" class="form-control<?php echo e($errors->has('fax') ? ' is-invalid' : ''); ?>" name="fax" autofocus="" value="<?php echo e($location->fax); ?>">
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'fax'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <div class="col-sm-6 offset-sm-3">
                        <button type="submit" class="btn btn-primary">
                            Save
                        </button>
                        <a href="<?php echo e(route('cp.menus.posts.edit', [3,3])); ?>" class="btn btn-secondary">
                            Cancel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    CKEDITOR.replace('address', config);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/location/edit.blade.php ENDPATH**/ ?>