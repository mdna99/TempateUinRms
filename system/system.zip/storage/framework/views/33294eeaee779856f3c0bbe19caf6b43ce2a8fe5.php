

<?php if($post->id == 3): ?>
<?php echo $__env->make('templates.location.index', [
'post' => $post
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif($post->id == 4): ?>
<?php echo $__env->make('templates.contact.form', [
'post' => $post
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.title', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="banner">
    <img src="<?php echo e(asset($cover)); ?>" onerror="this.src='<?php echo e(asset('assets/img/slider.JPG')); ?>'">
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid">
    <div class="post">
        <div class="row">
            <?php echo $__env->make('components.sidebar', [
            'sidebars' => $sidebars
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-8" id="print-area">
                <div class="content">
                    <h1><?php echo e($post->title); ?></h1>
                    <?php echo $post->description; ?>

                    <?php if(count($post->files) != 0): ?>
                    <div class="attachment">
                        <h2>Download</h2>
                        <div class="file">
                            <?php $__currentLoopData = $post->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(asset($file->file)); ?>" target="_blank">
                                <!--<img src="<?php echo e(asset('assets/img/file.png')); ?>">-->
                                <?php echo e($file->title); ?>

                            </a>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                        </div>
                    </div>                    
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
        <?php if($post->thumbnail): ?>
        <img src="<?php echo e(asset($post->thumbnail)); ?>" class="cover">
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/templates/post/index.blade.php ENDPATH**/ ?>