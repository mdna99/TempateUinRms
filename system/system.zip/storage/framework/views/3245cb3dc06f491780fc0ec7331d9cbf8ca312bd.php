

<?php $__env->startSection('title', 'Media Sosial'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-start mb-2">
    <h2 class="section-title m-0 mb-4">
        Data Media Sosial
    </h2>
    <a href="<?php echo e(route('cp.social-media.create')); ?>" class="btn btn-primary">Add New</a>
</div>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th class="table-fit">#</th>
                        <th>Nama Sosial Media</th>
                        <th class="table-fit">Link</th>
                        <th class="table-fit">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $socialMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="table-fit"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <i class="<?php echo e($item->icon); ?> mr-2"></i>
                                    <a href="<?php echo e($item->link); ?>" target="_blank"><?php echo e($item->link); ?></a>
                                </div>
                            </td>
                            <td class="table-fit">
                                <form id="form-action" method="POST" action="<?php echo e(route('cp.social-media.destroy', $item)); ?>" accept-charset="UTF-8">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="table-links">
                                        <a href="<?php echo e(route('cp.social-media.edit', $item)); ?>">Edit</a>
                                        <div class="bullet"></div>
                                        <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Anda yakin akan menghapus data ?');">
                                            Delete
                                        </button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">Tidak ada data.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/social-media/index.blade.php ENDPATH**/ ?>