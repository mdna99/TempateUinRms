<?php $__env->startSection('title', 'Pengaturan Program Pensiun'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <form id="setting-form" action="<?php echo e(route('cp.retirement-settings.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <p class="text-muted">Perhitungan pinjaman</p>
            <div class="form-group row align-items-center">
                <label for="credit_percentage" class="m-0 form-control-label col-sm-2 text-md-right">Persentase</label>
                <div class="col-sm-6 col-md-6">
                    <input type="number" id="credit_percentage" name="setting[credit_percentage]" class="form-control" value="<?php echo e(data_get($setting, 'credit_percentage')); ?>">
                </div>
            </div>
            <div class="form-group row align-items-center">
                <label for="credit_time" class="m-0 form-control-label col-sm-2 text-md-right">Waktu Maksimal<br>*dalam tahun</label>
                <div class="col-sm-6 col-md-6">
                    <input type="number" id="credit_time" name="setting[credit_time]" class="form-control" value="<?php echo e(data_get($setting, 'credit_time')); ?>">
                </div>
            </div>
            <div class="form-group row align-items-center">
                <label for="credit_age" class="m-0 form-control-label col-sm-2 text-md-right">Umur Maksimal</label>
                <div class="col-sm-6 col-md-6">
                    <input type="number" id="credit_age" name="setting[credit_age]" class="form-control" value="<?php echo e(data_get($setting, 'credit_age')); ?>">
                </div>
            </div>
            <div class="form-group row align-items-center">
                <label for="credit_interest_rate" class="m-0 form-control-label col-sm-2 text-md-right">Interest Rate</label>
                <div class="col-sm-6 col-md-6">
                    <input type="number" id="credit_interest_rate" name="setting[credit_interest_rate]" class="form-control" value="<?php echo e(data_get($setting, 'credit_interest_rate')); ?>" step="0.001">
                </div>
            </div>
            <div class="form-group row align-items-center">
                <label for="credit_max_plafond" class="m-0 form-control-label col-sm-2 text-md-right">Max Plafond</label>
                <div class="col-sm-6 col-md-6">
                    <input type="number" id="credit_max_plafond" name="setting[credit_max_plafond]" class="form-control" value="<?php echo e(data_get($setting, 'credit_max_plafond')); ?>">
                </div>
            </div>

            <p class="text-muted">Halaman Kalkulator Program Pensiun</p>
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="id-tab" data-toggle="tab" href="#id" role="tab" aria-controls="id" aria-selected="true">Indonesia</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="en-tab" data-toggle="tab" href="#en" role="tab" aria-controls="en" aria-selected="false">English</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="id" role="tabpanel" aria-labelledby="id-tab">
                                    <div class="form-group">
                                        <label for="retirement_title_id" class="col-form-label text-right">Judul</label>
                                        <input type="text" id="retirement_title_id" class="form-control" name="setting[retirement_title_id]" value="<?php echo e(data_get($setting, 'retirement_title_id')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="retirement_description_id" class="col-form-label text-right">Deskripsi</label>
                                        <textarea type="text" id="retirement_description_id" name="setting[retirement_description_id]" class="form-control" rows="3" style="height: auto;"><?php echo e(data_get($setting, 'retirement_description_id')); ?></textarea>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="en" role="tabpanel" aria-labelledby="en-tab">
                                    <div class="form-group">
                                        <label for="retirement_title_en" class="col-form-label text-right">Title</label>
                                        <input type="text" id="retirement_title_en" class="form-control" name="setting[retirement_title_en]" value="<?php echo e(data_get($setting, 'retirement_title_en')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="retirement_description_en" class="col-form-label text-right">Description</label>
                                        <textarea type="text" id="retirement_description_en" name="setting[retirement_description_en]" class="form-control" rows="3" style="height: auto;"><?php echo e(data_get($setting, 'retirement_description_en')); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Gambar</label>
                                <div class="mb-2">
                                    <img src="<?php echo e(asset(data_get($setting, 'retirement_image'))); ?>" class="img-fluid" alt="" id="upload-img-preview">
                                    <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Hapus Gambar</a>
                                </div>
                                <div class="custom-file">
                                    <input type="file" accept="image/*" name="setting[retirement_image]" id="image" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('setting.retirement_image') ? ' is-invalid' : ''); ?>">
                                    <label class="custom-file-label " for="image">Choose file</label>
                                    <?php echo $__env->make('cp.components.form-error', ['field' => 'setting.retirement_image'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="form-text text-muted">The image must have a maximum size of 2MB</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <p class="text-muted">Halaman Info Program Pensiun</p>
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs" id="myTabInfo" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="id-info-tab" data-toggle="tab" href="#idinfo" role="tab" aria-controls="idinfo" aria-selected="true">Indonesia</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="en-info-tab" data-toggle="tab" href="#eninfo" role="tab" aria-controls="eninfo" aria-selected="false">English</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabInfoContent">
                                <div class="tab-pane fade show active" id="idinfo" role="tabpanel" aria-labelledby="id-info-tab">
                                    <div class="form-group">
                                        <label for="retirement_title_info_id" class="col-form-label text-right">Judul</label>
                                        <input type="text" id="retirement_title_info_id" class="form-control" name="setting[retirement_title_info_id]" value="<?php echo e(data_get($setting, 'retirement_title_info_id')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="retirement_description_info_id" class="col-form-label text-right">Deskripsi</label>
                                        <textarea type="text" id="retirement_description_info_id" name="setting[retirement_description_info_id]" class="form-control" rows="3" style="height: auto;"><?php echo e(data_get($setting, 'retirement_description_info_id')); ?></textarea>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="eninfo" role="tabpanel" aria-labelledby="en-info-tab">
                                    <div class="form-group">
                                        <label for="retirement_title_info_en" class="col-form-label text-right">Title</label>
                                        <input type="text" id="retirement_title_info_en" class="form-control" name="setting[retirement_title_info_en]" value="<?php echo e(data_get($setting, 'retirement_title_info_en')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="retirement_description_info_en" class="col-form-label text-right">Description</label>
                                        <textarea type="text" id="retirement_description_info_en" name="setting[retirement_description_info_en]" class="form-control" rows="3" style="height: auto;"><?php echo e(data_get($setting, 'retirement_description_info_en')); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Gambar</label>
                                <div class="mb-2">
                                    <img src="<?php echo e(asset(data_get($setting, 'retirement_image_info'))); ?>" class="img-fluid" alt="" id="upload-img-preview1">
                                    <a href="#" class="text-danger" id="upload-img-delete1" style="display: none;">Hapus Gambar</a>
                                </div>
                                <div class="custom-file">
                                    <input type="file" accept="image/*" name="setting[retirement_image_info]" id="image" class="custom-file-input js-upload-image1 form-control<?php echo e($errors->has('setting.retirement_image_info') ? ' is-invalid' : ''); ?>">
                                    <label class="custom-file-label" for="image">Choose file</label>
                                    <?php echo $__env->make('cp.components.form-error', ['field' => 'setting.retirement_image_info'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="form-text text-muted">The image must have a maximum size of 2MB</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <p class="text-muted">Inbox Info</p>
            <div class="form-group row align-items-center">
                <label for="email_destination" class="m-0 form-control-label col-sm-2 text-md-right">Email Tujuan Inbox</label>
                <div class="col-sm-6 col-md-6">
                    <input type="email" id="email_destination" name="setting[email_destination]" class="form-control" value="<?php echo e(data_get($setting, 'email_destination')); ?>">
                </div>
            </div>
            <div class="form-group row align-items-center">
                <div class="col-sm-6 col-md-6 offset-md-2">
                    <button class="btn btn-primary" id="save-btn">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('.js-upload-image1').change(function(event) {
        makePreview1(this);
        $('#upload-img-preview1').show();
        $('#upload-img-delete1').show();
    });

    function makePreview1(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#upload-img-preview1').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#upload-img-delete1').click(function(event) {
        event.preventDefault();

        $('#upload-img-preview1').attr('src', '').hide();
        $('.custom-file-input1').val(null);
        $(this).hide();
    });
    CKEDITOR.replace('retirement_description_id', config);
    CKEDITOR.replace('retirement_description_en', config);
    CKEDITOR.replace('retirement_description_info_id', config);
    CKEDITOR.replace('retirement_description_info_en', config);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/cp/retirement-setting/edit.blade.php ENDPATH**/ ?>