

<?php $__env->startSection('title'); ?>
<?php if($menu->parent_id == 0): ?>
<a href="<?php echo e(route('cp.menus.show',$menu->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
<?php else: ?>
<a href="<?php echo e(route('cp.menus.submenus.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
<?php endif; ?>
<h1>Edit Post</h1>
<?php echo $__env->make('cp.components.breadcrumb', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.menus.posts.update', [$menu,$post])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input type="hidden" name="category" value="berita">

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Content</h4>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="id-tab" data-toggle="tab" href="#id" role="tab" aria-controls="id" aria-selected="true">Indonesia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="en-tab" data-toggle="tab" href="#en" role="tab" aria-controls="en" aria-selected="false">English</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="id" role="tabpanel" aria-labelledby="id-tab">
                            <div class="form-group">
                                <label for="title_id" class="col-form-label text-right">Title</label>
                                <input type="text" id="title_id" class="form-control<?php echo e($errors->has('title_id') ? ' is-invalid' : ''); ?>" name="title_id" autofocus="" value="<?php echo e($post->translate('id')->title); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_id" class="col-form-label text-right">Description</label>
                                <textarea rows="4" type="text" id="description_id" class="form-control<?php echo e($errors->has('description_id') ? ' is-invalid' : ''); ?>" name="description_id" autofocus="" style="height: auto"><?php echo e($post->translate('id')->description); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>         
                        </div>
                        <div class="tab-pane fade" id="en" role="tabpanel" aria-labelledby="en-tab">
                            <div class="form-group">
                                <label for="title_en" class="col-form-label text-right">Title</label>
                                <input type="text" id="title_en" class="form-control<?php echo e($errors->has('title_en') ? ' is-invalid' : ''); ?>" name="title_en" autofocus="" value="<?php echo e($post->translate('en')->title); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_en" class="col-form-label text-right">Description</label>
                                <textarea rows="4" type="text" id="description_en" class="form-control<?php echo e($errors->has('description_en') ? ' is-invalid' : ''); ?>" name="description_en" autofocus="" style="height: auto"><?php echo e($post->translate('en')->description); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>         
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Meta</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="custom-switch p-0">
                            <input type="checkbox" name="is_running_text" class="custom-switch-input" <?php echo e(($post->is_running_text == 1) ? 'checked' : ''); ?>>
                            <span class="custom-switch-indicator"></span>
                            <span class="custom-switch-description">Set as running text</span>
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="custom-switch p-0">
                            <input type="checkbox" name="is_featured_product" class="custom-switch-input" <?php echo e(($post->is_featured_product == 1) ? 'checked' : ''); ?>>
                            <span class="custom-switch-indicator"></span>
                            <span class="custom-switch-description">Set as featured product in homepage</span>
                        </label>
                    </div>
                    <div class="form-group<?php echo e($errors->has('is_published') ? ' has-error' : ''); ?>">
                        <label for="is_published">Publishing Status</label>
                        <select id="is_published" name="is_published" class="form-control">
                            <option value="1" <?php echo e($post->is_published == 1 ? 'selected' : ''); ?>>Published</option>
                            <option value="0" <?php echo e($post->is_published == 0 ? 'selected' : ''); ?>>Draft</option>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'is_published'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label>Cover Image</label>
                        <div class="mb-2">
                            <img src="<?php echo e(asset($post->cover)); ?>" class="img-fluid" alt="" id="upload-img-preview">
                            <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Delete Cover Image</a>
                        </div>
                        <div class="custom-file">
                            <input type="file" accept="image/*" name="cover" id="cover" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>">
                            <label class="custom-file-label " for="cover">Choose file</label>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'cover'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Thumbnail Image</label>
                        <div class="mb-2">
                            <img src="<?php echo e(asset($post->thumbnail)); ?>" class="img-fluid" alt="" id="upload-img-preview1">
                            <a href="#" class="text-danger" id="upload-img-delete1" style="display: none;">Delete Thumbnail Image</a>
                        </div>
                        <div class="custom-file">
                            <input type="file" accept="image/*" name="thumbnail" id="thumbnail" class="custom-file-input1 js-upload-image1 form-control<?php echo e($errors->has('thumbnail') ? ' is-invalid' : ''); ?>">
                            <label class="custom-file-label " for="thumbnail">Choose file</label>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'thumbnail'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('template') ? ' has-error' : ''); ?>">
                        <label for="template">Template Page</label>
                        <select name="template" class="form-control">
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($template); ?>" <?php echo e($template == $post->template ? 'selected' : ''); ?>><?php echo e($template); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'template'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>                
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Files</h4>
                    <div class="card-header-action">
                        <button class="btn btn-primary tambah-file">
                            Add File
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th scope="col">Order</th>
                                <th scope="col">Title</th>
                                <th scope="col">File</th>
                                <th scope="col" class="table-fit">Action</th>
                            </tr>
                        </thead>
                        <tbody id="body-table">
                            <?php $__currentLoopData = $post->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="table-fit">
                                    <?php if(!$loop->first): ?>
                                    <button type="button" id="<?php echo e($file->id); ?>" data-type="up" class="btn btn-sm btn-light move">
                                        Move up <i class="fa fa-arrow-circle-up"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php if(!$loop->last): ?>
                                    <button type="button" id="<?php echo e($file->id); ?>" data-type="down" class="btn btn-sm btn-light move">
                                        Move down <i class="fa fa-arrow-circle-down"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($file->title); ?>

                                </td>
                                <td>
                                    <span class="badge badge-secondary mb-2"><i class="fas fa-file"></i>&nbsp;
                                        <a class="text-white" href="<?php echo e(asset($file->file)); ?>" target="_blank"><?php echo e($file->title); ?></a>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-danger delete-<?php echo e($file->id); ?>" type="button" onclick="deleteFile(<?php echo e($file->id); ?>)"><i class="fa fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                                     
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Save
                    </button>
                    <?php if($menu->parent_id == 0): ?>
                    <a href="<?php echo e(route('cp.menus.show',$menu->id)); ?>" class="btn btn-secondary">
                        Cancel
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('cp.menus.submenus.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-secondary">
                        Cancel
                    </a>
                    <?php endif; ?>
                </div>
            </div>            
        </div>
    </div>
</form>
<div class="d-none">
    <table>
        <tbody id="table-row">
            <tr>
                <td></td>
                <td>
                    <input type="text" class="form-control" id="title_files" name="title_files[]" required="">
                </td>
                <td>
                    <input type="file" class="form-control" name="files[]" required="">
                </td>
                <td>
                    <button class="btn btn-danger hapus-file" type="button"><i class="fa fa-trash"></i></button>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php if($post->id == 3): ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="text-black-50">Location</h4>
                <div class="card-header-action">
                    <a href="<?php echo e(route('cp.locations.create')); ?>" class="btn btn-primary">
                        Add Location
                    </a>
                </div>                
            </div>
            <div class="card-body">
                <table class="table table-responsive">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Area</th>
                            <th scope="col">Unit</th>
                            <th scope="col">Address</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Fax</th>
                            <th scope="col" class="table-fit">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $rowNumber = ($locations->currentpage()-1) * $locations->perpage() + 1;
                        ?>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="table-fit"><?php echo e($rowNumber++); ?></td>
                            <td class="table-fit"><?php echo e($location->area->name); ?></td>
                            <td class="table-fit"><?php echo e($location->unit); ?></td>
                            <td class="table-fit"><?php echo $location->address; ?></td>
                            <td class="table-fit"><?php echo e($location->phone); ?></td>
                            <td class="table-fit"><?php echo e($location->fax); ?></td>
                            <td class="table-fit">
                                <form id="form-action" method="POST" action="<?php echo e(route('cp.locations.destroy', $location)); ?>" accept-charset="UTF-8">
                                    <input name="_method" type="hidden" value="DELETE">
                                    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">

                                    <div class="table-links">
                                        <a href="<?php echo e(route('cp.locations.edit', $location)); ?>">Edit</a>
                                        <div class="bullet"></div>
                                        <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Are you sure want to delete it ?');">
                                            Delete
                                        </button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $('.js-upload-image1').change(function (event) {
        makePreview1(this);
        $('#upload-img-preview1').show();
        $('#upload-img-delete1').show();
    });

    function makePreview1(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#upload-img-preview1').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#upload-img-delete1').click(function (event) {
        event.preventDefault();

        $('#upload-img-preview1').attr('src', '').hide();
        $('.custom-file-input1').val(null);
        $(this).hide();
    });
    
    $('body').on('click', '.tambah-file', function (event) {
        event.preventDefault();
        var template = $('#table-row').html();
        $('#body-table').append(template);
    });
    $('body').on('click', '.hapus-file', function (event) {
        event.preventDefault();
        var tableParent = $(this).closest('table');
        var trParent = $(this).closest('tr');
        trParent.remove();
    });
    function deleteFile(id) {
        var done = confirm('Are you sure want to delete it ?');
        if (done) {
            $.ajax({
                type: "DELETE",
                url: "<?php echo e(url('cp/delete-file')); ?>",
                data: {id: id},
                success: function (result) {
                    if (result) {
                        var tableParent = $('.delete-' + id).closest('table');
                        var trParent = $('.delete-' + id).closest('tr');
                        trParent.remove();
                        alert('file deleted !');
                    } else {
                        alert('failed to delete file');
                    }
                }
            });
        }
    }
    $('.move').click(function(event) {
            $.post('<?php echo e(route('cp.move-file')); ?>', {
                type: $(this).attr('data-type'),
                id: $(this).attr('id')
            }, function(data, textStatus, xhr) {
                window.location.reload();
            });
        });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/dev/system/resources/views/cp/post/edit.blade.php ENDPATH**/ ?>