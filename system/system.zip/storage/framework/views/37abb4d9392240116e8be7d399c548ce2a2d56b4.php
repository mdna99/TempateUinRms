

<?php $__env->startSection('title', 'Exchange Rates'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="d-flex justify-content-between align-items-start mb-2">
            <h2 class="section-title m-0 mb-4">
                Data Exchange Rates
            </h2>
            <a href="<?php echo e(route('cp.exchanges.create')); ?>" class="btn btn-primary">Add New</a>
        </div>
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Rate</th>
                                <th>Sell</th>
                                <th>Buy</th>
                                <th class="table-fit">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $date = '';
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $exchanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php if($date != $item->created_at->format('d F Y')): ?>
                                    <?php echo e(Carbon\Carbon::parse($item->created_at)->formatLocalized('%A, %d %B %Y')); ?>

                                    <?php
                                    $date = $item->created_at->format('d F Y');
                                    ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->rate->name); ?></td>
                                <td><?php echo e($item->sell); ?></td>
                                <td><?php echo e($item->buy); ?></td>
                                <td class="table-fit">
                                    <form id="form-action" method="POST" action="<?php echo e(route('cp.exchanges.destroy', $item)); ?>" accept-charset="UTF-8">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>

                                        <div class="table-links">
                                            <a href="<?php echo e(route('cp.exchanges.edit', $item)); ?>">Edit</a>
                                            <div class="bullet"></div>
                                            <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Are you sure want to delete it ?');">
                                                Delete
                                            </button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">No data.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="d-flex justify-content-between align-items-start mb-2">
            <h2 class="section-title m-0 mb-4">
                Data Rates
            </h2>
            <a href="<?php echo e(route('cp.rates.create')); ?>" class="btn btn-primary">Add New</a>
        </div>
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="table-fit">#</th>
                                <th>Name</th>
                                <th class="table-fit">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="table-fit"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td class="table-fit">
                                    <form id="form-action" method="POST" action="<?php echo e(route('cp.rates.destroy', $item)); ?>" accept-charset="UTF-8">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>

                                        <div class="table-links">
                                            <a href="<?php echo e(route('cp.rates.edit', $item)); ?>">Edit</a>
                                            <div class="bullet"></div>
                                            <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Are you sure want to delete it ?');">
                                                Delete
                                            </button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">No data.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/exchange/index.blade.php ENDPATH**/ ?>