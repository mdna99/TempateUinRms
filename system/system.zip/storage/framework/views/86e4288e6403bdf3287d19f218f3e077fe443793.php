

<?php $__env->startSection('content'); ?>
<div class="header-title">
    <h1><?php echo e(__('search.result')); ?></h1>
    <div class="breadcrumb">
        <a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a>
        <a><?php echo e(__('search.result')); ?></a>
    </div>
</div>
<div class="banner">
    <img src="" onerror="this.src='<?php echo e(asset('assets/img/slider.JPG')); ?>'">
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid">
    <div class="post">
        <div class="row">
            <div class="col-md-4 d-none d-md-block d-lg-block">
                <div class="sidebar">
                    <ul>
                        <li class="active"><a><?php echo e(__('search.result')); ?></a></li>
                        <li><a href="<?php echo e(url('')); ?>">Home</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8">
                <div class="content">
                    <h1><?php echo e(__('search.result')); ?></h1>
                    <p><?php echo e(__('search.result_title')); ?> <span class="font-weight-bold">"<?php echo e(request('query')); ?>"</span>, <?php echo e($posts->total()); ?> <?php echo e(__('search.result_total')); ?></p>
                    <div class="row">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-6">
                            <div class="tile">
                                <div class="image">
                                    <img src="<?php echo e(asset($post->thumbnail)); ?>" onerror="this.src='<?php echo e(asset('assets/img/nocover.png')); ?>'">
                                </div>
                                <p class="date"><?php echo e($post->formatted_published_at); ?></p>
                                <a href="<?php echo e(generateUrl($post->slug)); ?>">
                                    <h2 class="title">
                                        <?php echo e($post->title); ?>

                                    </h2>
                                </a>
                            </div>
                        </div>                                                                     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                           
                    </div>
                    <?php if(count($posts->links()->elements[0]) > 1): ?>
                    <?php echo e($posts->appends(request()->query())->links('components.pagination')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/dev/system/resources/views/search/index.blade.php ENDPATH**/ ?>