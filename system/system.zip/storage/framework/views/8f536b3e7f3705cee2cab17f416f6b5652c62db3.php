<?php $__env->startSection('content'); ?>
<div class="sidebar">
    <ul>
        <?php $__currentLoopData = $sidebar_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        if($menu->id == 1){
        $i = '#home';
        } else
        if($menu->id == 2){
        $i = '#about';
        } else
        if($menu->id == 3){
        $i = '#service';
        } else
        if($menu->id == 4){
        $i = '#work';
        } else
        if($menu->id == 5){
        $i = '#contact';
        }
        ?>
        <a href="<?php echo e(url('/'.$i)); ?>">
            <li class="<?php echo e($menu->id == 4 ? 'active' : ''); ?>">
                <?php echo e($menu->title); ?>

            </li>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    </ul>
</div>
<div id="work" class="background" style="background-image: url(<?php echo e(asset($menu->cover)); ?>)">
    <div class="title">
        <h1><?php echo e($submenu->title); ?></h1>
    </div>
    <div class="row">
        <div class="col-md-7 tab-content display" id="myTabA">
            <?php $__currentLoopData = $submenu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab-pane fade <?php echo e($loop->iteration == 1 ? 'show active' : ''); ?>" id="image-<?php echo e($loop->iteration); ?>" role="tabpanel" aria-labelledby="<?php echo e($loop->iteration); ?>-tab">
                <img id="modalImage-<?php echo e($post->id); ?>" class="modalImage" src="<?php echo e(asset($post->cover)); ?>" alt="<?php echo e($post->title); ?>">                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-5">
            <ul class="nav" id="myTab" role="tablist">
                <?php $__currentLoopData = $submenu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item thumbnail">
                    <a class="nav-link <?php echo e($loop->iteration == 1 ? 'active' : ''); ?> p-0" id="<?php echo e($loop->iteration); ?>-tab" data-toggle="tab" role="tab" aria-controls="<?php echo e($loop->iteration); ?>" aria-selected="true" data-target="#image-<?php echo e($loop->iteration); ?>" data-secondary="#desc-<?php echo e($loop->iteration); ?>">
                        <img src="<?php echo e(asset($post->cover)); ?>" alt="<?php echo e($post->title); ?>">
                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabB">                
                <?php $__currentLoopData = $submenu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->iteration == 1 ? 'show active' : ''); ?>" id="desc-<?php echo e($loop->iteration); ?>" role="tabpanel" aria-labelledby="<?php echo e($loop->iteration); ?>-tab">
                    <div class="description">
                        <p><?php echo e($post->title); ?></p>
                        <?php echo $post->description; ?>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>    
    <a href="<?php echo e(url('/#work')); ?>" class="btn btn-back"><i class="fas fa-caret-left"></i></a>
</div>

<div id="myModal" class="modal">
    <span class="close">&times;</span>
    <img class="modal-content" id="img01">
    <div id="caption"></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).on('click', '#myTab a', function (e) {
        otherTabs = $(this).attr('data-secondary').split(',');
        console.log(otherTabs);
        for (i = 0; i < otherTabs.length; i++) {
            nav = $('<ul class="nav d-none" id="tmpNav"></ul>');
            nav.append('<li class="nav-item"><a href="#" data-toggle="tab" data-target="' + otherTabs[i] + '">nav</a></li>"');
            nav.find('a').tab('show');
        }
    });
    
    var modal = document.getElementById("myModal");
    <?php $__currentLoopData = $submenu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    var img<?php echo e($post->id); ?> = document.getElementById("modalImage-<?php echo e($post->id); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    <?php $__currentLoopData = $submenu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    img<?php echo e($post->id); ?>.onclick = function () {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    var span = document.getElementsByClassName("close")[0];
    span.onclick = function () {
        modal.style.display = "none";
    }    
    $(document).keyup(function(e) {
     if (e.keyCode == 27) {
        modal.style.display = "none";
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/submenu/show.blade.php ENDPATH**/ ?>