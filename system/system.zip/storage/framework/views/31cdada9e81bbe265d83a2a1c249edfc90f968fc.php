<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.permissions.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Edit Permission</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.permissions.update', $role)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Role <?php echo e($role->name); ?></h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-sm">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Code</th>
                                <th>Deskripsi</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $checked = NULL;
                            ?>
                            <tr>
                                <td class="table-fit text-center"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($code->name); ?></td>
                                <td><?php echo e($code->description); ?></td>
                                <td>
                                    <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($permission->privilege_code_id == $code->id): ?>
                                    <?php
                                    $checked = 'checked';
                                    ?>
                                    <?php break; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <label class="custom-switch mt-2">
                                        <input type="checkbox" name="permissions[<?php echo e($code->id); ?>]" class="custom-switch-input" <?php echo e($checked ? $checked : ''); ?>>
                                        <span class="custom-switch-indicator"></span>
                                    </label>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <a href="<?php echo e(route('cp.permissions.index')); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/cp/permission/edit.blade.php ENDPATH**/ ?>