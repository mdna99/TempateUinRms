<?php $__env->startSection('title', 'Slider'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-start mb-2">
    <h2 class="section-title m-0 mb-4">
        Data Slider
    </h2>
    <a href="<?php echo e(route('cp.sliders.create')); ?>" class="btn btn-primary">Add New</a>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="table-fit">#</th>
                                <th>Order</th>
                                <th style="width: 175px;">Image</th>
                                <th>Caption</th>
                                <th>Link</th>
                                <th class="table-fit">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="table-fit"><?php echo e($loop->iteration); ?></td>
                                    <td class="table-fit">
                                        <?php if(!$loop->first): ?>
                                            <button type="button" id="<?php echo e($slider->id); ?>" data-type="up" class="btn btn-sm btn-light move">
                                                Move up <i class="fa fa-arrow-circle-up"></i>
                                            </button>
                                        <?php endif; ?>
                                        <?php if(!$loop->last): ?>
                                            <button type="button" id="<?php echo e($slider->id); ?>" data-type="down" class="btn btn-sm btn-light move">
                                                Move down <i class="fa fa-arrow-circle-down"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <img src="<?php echo e(asset($slider->image)); ?>" class="img-fluid my-2">
                                    </td>
                                    <td><?php echo $slider->caption; ?></td>
                                    <td class="table-fit">
                                        <?php if($slider->link): ?>
                                            <a href="<?php echo e(url($slider->link)); ?>" target="_blank">
                                                <?php echo e($slider->link); ?> <i class="fas fa-external-link-alt"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="table-fit">
                                        <form id="form-action" method="POST" action="<?php echo e(route('cp.sliders.destroy', $slider)); ?>" accept-charset="UTF-8">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>

                                            <div class="table-links">
                                                <a href="<?php echo e(route('cp.sliders.edit', $slider)); ?>">Edit</a>
                                                <div class="bullet"></div>
                                                <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Anda yakin akan menghapus data ?');">
                                                    Delete
                                                </button>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Tidak ada data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('.move').click(function(event) {
            $.post('<?php echo e(route('cp.move-slider')); ?>', {
                type: $(this).attr('data-type'),
                id: $(this).attr('id')
            }, function(data, textStatus, xhr) {
                window.location.reload();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/cp/slider/index.blade.php ENDPATH**/ ?>