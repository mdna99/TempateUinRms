<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.privilege-codes.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Edit Privilege Code</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.privilege-codes.update', $code)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Konten</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="name">Nama</label>
                        <input type="text" id="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" autofocus="" value="<?php echo e($code->name); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="url">Url</label>
                        <input type="text" id="url" class="form-control<?php echo e($errors->has('url') ? ' is-invalid' : ''); ?>" name="url" autofocus="" value="<?php echo e($code->url); ?>">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'url'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="description">Deskripsi</label>
                        <textarea rows="3" style="height: auto" type="text" id="description" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" autofocus><?php echo e($code->description); ?></textarea>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <a href="<?php echo e(route('cp.roles.index')); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/privilege-code/edit.blade.php ENDPATH**/ ?>