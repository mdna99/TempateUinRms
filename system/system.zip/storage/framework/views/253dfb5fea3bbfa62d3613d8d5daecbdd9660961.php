

<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <?php if($menu->parent_id == 0): ?>
    <a href="<?php echo e(route("cp.menus.show",$menu->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php else: ?>
    <a href="<?php echo e(route('cp.menus.submenus.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php endif; ?>
</div>
<h1>Add Submenu</h1>
<?php echo $__env->make('cp.components.breadcrumb', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route("cp.menus.submenus.store", $menu)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Content</h4>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="id-tab" data-toggle="tab" href="#id" role="tab" aria-controls="id" aria-selected="true">Indonesia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="en-tab" data-toggle="tab" href="#en" role="tab" aria-controls="en" aria-selected="false">English</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="id" role="tabpanel" aria-labelledby="id-tab">
                            <div class="form-group">
                                <label for="title_id" class="col-form-label text-right">Title</label>
                                <input type="text" id="title_id" class="form-control<?php echo e($errors->has('title_id') ? ' is-invalid' : ''); ?>" name="title_id" autofocus="" value="<?php echo e(old('title_id')); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_id" class="col-form-label text-right">Description</label>
                                <textarea rows="4" type="text" id="description_id" class="form-control<?php echo e($errors->has('description_id') ? ' is-invalid' : ''); ?>" name="description_id" autofocus="" style="height: auto"><?php echo e(old('description_id')); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>         
                        </div>
                        <div class="tab-pane fade" id="en" role="tabpanel" aria-labelledby="en-tab">
                            <div class="form-group">
                                <label for="title_en" class="col-form-label text-right">Title</label>
                                <input type="text" id="title_en" class="form-control<?php echo e($errors->has('title_en') ? ' is-invalid' : ''); ?>" name="title_en" autofocus="" value="<?php echo e(old('title_en')); ?>">
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'title_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="form-group">
                                <label for="description_en" class="col-form-label text-right">Description</label>
                                <textarea rows="4" type="text" id="description_en" class="form-control<?php echo e($errors->has('description_en') ? ' is-invalid' : ''); ?>" name="description_en" autofocus="" style="height: auto"><?php echo e(old('description_en')); ?></textarea>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>         
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Meta</h4>
                </div>
                <div class="card-body">
                    <div class="form-group<?php echo e($errors->has('is_published') ? ' has-error' : ''); ?>">
                        <label for="is_published">Publishing Status</label>
                        <select id="is_published" name="is_published" class="form-control">
                            <option value="1" <?php echo e(old('is_published') == 1 ? 'selected' : ''); ?>>Published</option>
                            <option value="0" <?php echo e(old('is_published') == 0 ? 'selected' : ''); ?>>Draft</option>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'is_published'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label>Cover</label>
                        <div class="mb-2">
                            <img src="" class="img-fluid" alt="" id="upload-img-preview" style="display: none;">
                            <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Delete Cover Image</a>
                        </div>
                        <div class="custom-file">
                            <input type="file" accept="image/*" name="cover" id="cover" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>">
                            <label class="custom-file-label " for="cover">Choose file</label>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'cover'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('template') ? ' has-error' : ''); ?>">
                        <label for="template">Template Page</label>
                        <select name="template" class="form-control">
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($template); ?>" <?php echo e($template == old('template') ? 'selected' : ''); ?>><?php echo e($template); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'template'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Save
                    </button>
                    <?php if($menu->parent_id == 0): ?>
                    <a href="<?php echo e(route("cp.menus.show",$menu->id)); ?>" class="btn btn-secondary">
                        Cancel
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('cp.menus.submenus.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-secondary">
                        Cancel
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/submenu/create.blade.php ENDPATH**/ ?>