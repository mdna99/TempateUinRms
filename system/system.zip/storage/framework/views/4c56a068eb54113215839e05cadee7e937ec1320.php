<?php if($errors->has($field)): ?>

	<span class="invalid-feedback">
        <strong><?php echo e($errors->first($field)); ?></strong>
    </span>

<?php endif; ?><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/cp/components/form-error.blade.php ENDPATH**/ ?>