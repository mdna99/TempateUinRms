<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.users.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Detail User</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <dl class="meta">       
                    <dt>Nama</dt>
                    <dd><?php echo e($user->name); ?></dd>
                    
                    <dt>Username</dt>
                    <dd><?php echo e($user->username); ?></dd>                  
                    
                    <dt>Email</dt>
                    <dd><?php echo e($user->email); ?></dd>  
                    
                    <dt>Role</dt>
                    <dd><?php echo e($user->role->name); ?></dd> 
                    
                    <dt>Created At</dt>
                    <dd><?php echo e($user->created_at->format('d F Y')); ?></dd>
                    
                    <dt>Updated At</dt>
                    <dd><?php echo e($user->updated_at->format('d F Y')); ?></dd>
                </dl>
            </div>
            <div class="card-footer bg-whitesmoke">
                <a href="<?php echo e(route('cp.users.index')); ?>" class="btn btn-secondary">
                    Kembali
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/user/show.blade.php ENDPATH**/ ?>