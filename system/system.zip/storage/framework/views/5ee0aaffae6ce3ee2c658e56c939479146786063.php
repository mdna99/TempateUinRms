<div class="col-md-4 d-none d-md-block d-lg-block">
    <?php if($post->menu->id == 4 || $post->menu->id == 8 || $post->menu->id == 9 || $post->menu->id == 10 || $post->menu->id == 11): ?>
    <div class="sidebar">
        <ul>
            <li class="active"><a href="<?php echo e(generateUrl($post->menu->slug)); ?>"><?php echo e($post->menu->title); ?></a></li>
            <li><a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a></li>
        </ul>
    </div>
    <?php else: ?>
    <div class="sidebar">
        <ul>
            <?php $__currentLoopData = $sidebars->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li <?php echo e($sidebar->title == $post->title ? 'class=active' : ''); ?>><a href="<?php echo e(generateUrl($sidebar->slug)); ?>"><?php echo e($sidebar->title); ?></a></li>                        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a></li>
        </ul>
    </div>
    <?php endif; ?>
</div><?php /**PATH /home/bankcapi/public_html/system/resources/views/components/sidebar.blade.php ENDPATH**/ ?>