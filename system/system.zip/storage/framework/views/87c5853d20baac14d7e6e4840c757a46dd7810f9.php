<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="detail-menu">
        <?php echo $__env->make('components.breadcrumb', [
        'breadcrumbs' => $breadcrumbs
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h1><?php echo e($menu->title); ?></h1>
        <?php if(count($submenus) != 0 && count($posts) != 0): ?>
        <div class="row">
            <div class="col-md-4">
                <div class="sidebar-button d-lg-none d-md-none">
                    <a href="#" onclick="showTabMenu(event)"><i class="fas fa-bars"></i> <?php echo e(__('menu.tab_menu')); ?></a>
                </div>
                <div class="sidebar">
                    <h3><?php echo e($menu->title); ?></h3>
                    <div class="first">
                        <?php $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(generateUrl($submenu->slug)); ?>"><i class="fas fa-chevron-right"></i> <?php echo e($submenu->title); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(generateUrl($post->slug)); ?>">
                            <div class="item">
                                <img src="<?php echo e(asset($post->cover)); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
                                <div class="content">
                                    <h2><?php echo e($post->title); ?></h2>
                                    <span><?php echo e($post->formatted_published_at); ?></span>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php elseif(count($submenus) != 0 && count($posts) == 0): ?>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo e(generateUrl($submenu->slug)); ?>">
                    <div class="item">
                        <img src="<?php echo e(asset($submenu->cover)); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
                        <div class="content">
                            <h2><?php echo e($submenu->title); ?></h2>
                            <span><?php echo e($post->formatted_published_at); ?></span>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 d-flex justify-content-center align-items-center no-data">
                <h3><?php echo e(__('search.no_data')); ?></h3>
            </div>
            <?php endif; ?>
        </div>
        <?php echo e($submenus->links('components.pagination')); ?>

        <?php elseif(count($submenus) == 0 && count($posts) != 0): ?>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo e(generateUrl($post->slug)); ?>">
                    <div class="item">
                        <img src="<?php echo e(asset($post->cover)); ?>" onerror="this.src='<?php echo e(asset('files/no-image.jpg')); ?>';">
                        <div class="content">
                            <h2><?php echo e($post->title); ?></h2>
                            <span><?php echo e($post->formatted_published_at); ?></span>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 d-flex justify-content-center align-items-center no-data">
                <h3><?php echo e(__('search.no_data')); ?></h3>
            </div>
            <?php endif; ?>
        </div>
        <?php echo e($posts->links('components.pagination')); ?>

        <?php else: ?>
        <div class="d-flex justify-content-center align-items-center no-data">
            <h3><?php echo e(__('search.no_data')); ?></h3>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/templates/menu/default.blade.php ENDPATH**/ ?>