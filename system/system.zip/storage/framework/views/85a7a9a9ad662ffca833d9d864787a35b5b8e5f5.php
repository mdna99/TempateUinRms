<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.title', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="banner">
    <img src="<?php echo e(asset($cover)); ?>" onerror="this.src='<?php echo e(asset('assets/img/slider.JPG')); ?>'">
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid">
    <div class="post">
        <div class="row">
            <?php echo $__env->make('components.sidebar', [
            'sidebars' => $sidebars
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-8">
                <div class="content">
                    <h1><?php echo e($post->title); ?></h1>
                    <?php if(session('success')): ?>
                    <?php echo session('success'); ?>

                    <?php else: ?>
                    <?php echo $post->description; ?>    
                    <div class="contact-form">
                        <p class="red">* HARUS DIISI</p>
                        <form action="<?php echo e(route('contact.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row align-items-center">
                                <label for="name" class="col-sm-2 col-form-label">NAMA<span class="red">*</span></label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="">
                                </div>
                            </div>
                            <div class="form-group row align-items-center">
                                <label for="name" class="col-sm-2 col-form-label">ALAMAT</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" name="address" value="">
                                </div>
                            </div>
                            <div class="form-group row align-items-center">
                                <label for="phone" class="col-sm-2 col-form-label">TELEPON<span class="red">*</span></label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" name="phone" value="">
                                </div>
                            </div>
                            <div class="form-group row align-items-center">
                                <label for="email" class="col-sm-2 col-form-label">EMAIL<span class="red">*</span></label>
                                <div class="col-sm-10">
                                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="message" class="col-sm-2 col-form-label">KOMENTAR/<br>PERTANYAAN<span class="red">*</span></label>
                                <div class="col-sm-10">
                                    <textarea rows="2" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" name="message"></textarea>
                                </div>
                            </div>
                            <div class="form-group row align-items-center">
                                <label for="verification" class="col-sm-2 col-form-label">VERIFIKASI<span class="red">*</span></label>
                                <div class="col-sm-10">
                                    <div class="g-recaptcha p-0"
                                         data-sitekey="<?php echo e(config('app.recapcha_key')); ?>">
                                    </div>
                                    <div class="invalid-feedback <?php echo e($errors->has('g-recaptcha-response') ? 'd-block' : ''); ?>"><?php echo e($errors->has('g-recaptcha-response') ? $errors->first('g-recaptcha-response') : ''); ?></div>
                                </div>
                            </div>
                            <input name="slug" class="d-none" value="<?php echo e(app()->getLocale().'/'.$post->slug); ?>">
                            <button type="submit" class="btn btn-submit btn-blue-gradient">SUBMIT</button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if(session('success')): ?>
        <img src="<?php echo e(asset($post->thumbnail)); ?>" class="cover">
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/templates/contact/index.blade.php ENDPATH**/ ?>