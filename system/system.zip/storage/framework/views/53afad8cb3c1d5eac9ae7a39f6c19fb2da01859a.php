<div class="bc">
    <a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?> <i class="fas fa-chevron-right"></i></a>
    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(generateUrl($breadcrumb->slug)); ?>" <?php if($loop->last): ?><?php echo e('class=active'); ?><?php endif; ?>><?php echo e($breadcrumb->title); ?> <?php if(!($loop->last)): ?><i class="fas fa-chevron-right"><?php endif; ?></i></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>