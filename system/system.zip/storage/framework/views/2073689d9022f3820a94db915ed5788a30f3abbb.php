<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <!--To prevent most search engine web crawlers from indexing a page on your site-->
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">

    <title><?php echo e(data_get($setting, 'name', '-')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>">

    <!-- General CSS Files -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/components.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/custom.css')); ?>">

    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline mr-auto">
                    <ul class="navbar-nav mr-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                        <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i class="fas fa-search"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                            <img alt="image" src="<?php echo e(asset('admin/avatar-1.png')); ?>" class="rounded-circle mr-1">
                            <div class="d-sm-none d-lg-inline-block"><?php echo e(Auth::user()->name); ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            
                            <a href="<?php echo e(url('')); ?>" target="_blank" class="dropdown-item has-icon">
                                <i class="fas fa-external-link-alt"></i> View Site
                            </a>
                            
                            
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item has-icon text-danger" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt"></i> <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                </ul>
            </nav>
            <div class="main-sidebar">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand">
                        <a href="<?php echo e(url('/cp')); ?>"><?php echo e(data_get($setting, 'name', '-')); ?></a>
                    </div>
                    <div class="sidebar-brand sidebar-brand-sm">
                        <a href="<?php echo e(url('/cp')); ?>">BC</a>
                    </div>
                    <ul class="sidebar-menu">
                        <li class="menu-header">Dashboard</li>
                        <li class="<?php echo e(activeLink('cp.dashboard', false)); ?>">
                            <a class="nav-link" href="<?php echo e(url('cp')); ?>">
                                <i class="fas fa-fire"></i><span>Dashboard</span>
                            </a>
                        </li>
                        <?php if(getSidebar('menus')): ?>
                        <li class="menu-header">Manage</li>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e(request()->segment(3) == $item->id ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(url('cp/menus/'.$item->id)); ?>">
                                <i class="fas fa-newspaper"></i> <span><?php echo e($item->title); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(getSidebar('contacts')): ?>
                        <li class="menu-header">Transactions</li>
                        <li class="<?php echo e(activeLink('cp.contacts')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.contacts.index')); ?>">
                                <i class="far fa-paper-plane"></i> <span>Kontak Kami</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('retirement-calculations') || getSidebar('retirement-inbox') || getSidebar('retirement-settings')): ?>
                        <li class="menu-header">Program Pensiun</li>
                        <?php endif; ?>
                        <?php if(getSidebar('retirement-calculations')): ?>
                        <li class="<?php echo e(activeLink('cp.retirement-calculations')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.retirement-calculations.index')); ?>">
                                <i class="fas fa-calculator"></i> <span>Hasil Kalkulasi</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('retirement-inbox')): ?>
                        <li class="<?php echo e(activeLink('cp.retirement-inbox')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.retirement-inbox.index')); ?>">
                                <i class="fas fa-envelope"></i> <span>Inbox Info</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('retirement-settings')): ?>
                        <li class="<?php echo e(activeLink('cp.retirement-settings.edit', false)); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.retirement-settings.edit')); ?>">
                                <i class="fas fa-tools"></i> <span>Pengaturan</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('menus') || getSidebar('exchanges') || getSidebar('interest-rates') || getSidebar('areas') || getSidebar('sliders') || getSidebar('social-media') || getSidebar('settings')): ?>
                        <li class="menu-header">Configure</li>
                        <?php endif; ?>
                        <?php if(getSidebar('menus')): ?>
                        <li class="<?php echo e(activeLink('cp.menus.index', false)); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.menus.index')); ?>">
                                <i class="fas fa-bars"></i> <span>Menu</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('exchanges')): ?>
                        <li class="<?php echo e(activeLink('cp.exchanges')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.exchanges.index')); ?>">
                                <i class="fas fa-exchange-alt"></i> <span>Exchange Rates</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('interest-rates')): ?>
                        <li class="<?php echo e(activeLink('cp.interest-rates.edit', false)); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.interest-rates.edit')); ?>">
                                <i class="fas fa-percent"></i> <span>Interest Rates</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('areas')): ?>
                        <li class="<?php echo e(activeLink('cp.areas')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.areas.index')); ?>">
                                <i class="fas fa-map-marker-alt"></i> <span>Area</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('sliders')): ?>
                        <li class="<?php echo e(activeLink('cp.sliders')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.sliders.index')); ?>">
                                <i class="fas fa-images"></i> <span>Slider</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('social-media')): ?>
                        <li class="<?php echo e(activeLink('cp.social-media')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.social-media.index')); ?>">
                                <i class="fas fa-link"></i> <span>Media Sosial</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(getSidebar('settings')): ?>
                        <li class="<?php echo e(activeLink('cp.settings.edit', false)); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.settings.edit')); ?>">
                                <i class="fas fa-cog"></i> <span>Settings</span>
                            </a>
                        </li>         
                        <?php endif; ?>
                        <?php if(getSidebar('users') || getSidebar('roles') || getSidebar('permissions')): ?>
                        <li class="menu-header">User Management</li>
                        <?php endif; ?>
                        <?php if(getSidebar('users')): ?>
                        <li class="<?php echo e(activeLink('cp.users')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.users.index')); ?>">
                                <i class="fas fa-users"></i> <span>User</span>
                            </a>
                        </li>                        
                        <?php endif; ?>
                        <?php if(getSidebar('roles')): ?>
                        <li class="<?php echo e(activeLink('cp.roles')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.roles.index')); ?>">
                                <i class="fas fa-lock"></i> <span>Role</span>
                            </a>
                        </li>                        
                        <?php endif; ?>
                        <?php if(getSidebar('permissions')): ?>
                        <li class="<?php echo e(activeLink('cp.permissions')); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.permissions.index')); ?>">
                                <i class="fas fa-tasks"></i> <span>Permission</span>
                            </a>
                        </li>               
                        <?php endif; ?>
                        <li class="menu-header">Profile</li>
                        <li class="<?php echo e(activeLink('cp.passwords.edit', false)); ?>">
                            <a class="nav-link" href="<?php echo e(route('cp.passwords.edit')); ?>">
                                <i class="fas fa-key"></i> <span>Change Password</span>
                            </a>
                        </li>     
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <h1><?php echo $__env->yieldContent('title'); ?></h1>
                    </div>
                    <?php echo $__env->make('cp.components.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>
            <footer class="main-footer">
                <div class="footer-left">
                    Copyright &copy; <?php echo e(date('Y')); ?>

                    <div class="bullet"></div> <a href="https://kadangkoding.com/">Kadang Koding Indonesia</a>
                </div>
            </footer>
        </div>
    </div>
    
    <!-- General JS Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
    <script src="<?php echo e(asset('admin/js/stisla.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/ckeditor.js')); ?>"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
        $('.js-upload-image').change(function(event) {
            makePreview(this);
            $('#upload-img-preview').show();
            $('#upload-img-delete').show();
        });

        function makePreview(input){
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#upload-img-preview').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $('#upload-img-delete').click(function(event) {
            event.preventDefault();

            $('#upload-img-preview').attr('src', '').hide();
            $('.custom-file-input').val(null);
            $(this).hide();
        });

        var config = {
            extraPlugins: 'uploadimage,image2,button,panelbutton,colorbutton',
            height: '30em',

            filebrowserBrowseUrl: '<?php echo e(url('elfinder/ckeditor')); ?>',
            filebrowserUploadUrl: '<?php echo e(route('cp.upload',['_token' => csrf_token()])); ?>',

            stylesSet: [{
                name: 'Narrow image',
                type: 'widget',
                widget: 'image',
                attributes: {
                    'class': 'image-narrow'
                }
            },{
                name: 'Wide image',
                type: 'widget',
                widget: 'image',
                attributes: {
                    'class': 'image-wide'
                }
            }],

            contentsCss: [
                'https://cdn.ckeditor.com/4.11.3/full-all/contents.css',
            ],

            image2_alignClasses: ['image-align-left', 'image-align-center', 'image-align-right'],
            image2_disableResizer: true,
            removeDialogTabs: 'link:upload;image:upload',
            allowedContent: true
        };
        CKEDITOR.replace('description_id', config);
        CKEDITOR.replace('description_en', config);
    </script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/layouts/cp.blade.php ENDPATH**/ ?>