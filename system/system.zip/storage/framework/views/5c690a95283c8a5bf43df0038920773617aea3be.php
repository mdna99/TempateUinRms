<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <?php if($menu->parent_id == 0): ?>
    <a href="<?php echo e(route('cp.menu.show',$menu->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php else: ?>
    <a href="<?php echo e(route('cp.menu.submenu.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php endif; ?>
</div>
<h1>Detail Post</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h2 class="section-title">
    <?php echo e($post->title); ?>

</h2>
<div class="row">
    <div class="col-8">
        <div class="card">
            <div class="card-body">
                <?php echo strip_tags($post->description); ?>

            </div>
        </div>
    </div>
    <div class="col-4">
        <div class="card">
            <div class="card-header">
                <h4 class="text-black-50">Meta</h4>
            </div>
            <div class="card-body">
                <dl class="row">
                    <dt class="col-12">Published At</dt>
                    <dd class="col-12"><?php echo e($post->created_at->format('d F Y')); ?></dd>

                    <dt class="col-12">Cover</dt>
                    <dd class="col-12">
                        <?php if($post->cover): ?>
                        <img src="<?php echo e(asset($post->cover)); ?>" class="img-fluid" alt="">
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </dd>
                </dl>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/cp/post/show.blade.php ENDPATH**/ ?>