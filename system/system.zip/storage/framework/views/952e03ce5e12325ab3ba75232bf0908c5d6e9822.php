

<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.exchanges.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Add Exchange Rate</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.exchanges.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Content</h4>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-sm-2 col-md-1 col-form-label">Date</label>
                        <div class="col-sm-10 col-md-11">
                            <input type="text" class="form-control" disabled="" value="<?php echo e(date('d-m-Y')); ?>">
                        </div>
                    </div>   
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th class="table-fit">Rate</th>
                                    <th>Sell</th>
                                    <th>Buy</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th>
                                        <?php echo e($rate->name); ?>

                                        <input type="text" class="d-none" name="rate_id[]" value="<?php echo e($rate->id); ?>">
                                    </th>
                                    <th>
                                        <input type="text" class="form-control" name="sell[]">
                                    </th>
                                    <th>
                                        <input type="text" class="form-control" name="buy[]">
                                    </th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Save
                    </button>
                    <a href="<?php echo e(route('cp.exchanges.index')); ?>" class="btn btn-secondary">
                        Cancel
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/dev/system/resources/views/cp/exchange/create.blade.php ENDPATH**/ ?>