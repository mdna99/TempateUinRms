<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <a href="<?php echo e(route('cp.users.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
</div>
<h1>Edit User</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.users.update', $user)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Konten</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="role_id">Role</label>
                        <select class="form-control<?php echo e($errors->has('role_id') ? ' is-invalid' : ''); ?>" name="role_id" <?php if($user->id == 1): ?> disabled <?php endif; ?>>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php echo e($user->role_id == $role->id ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'role_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="name">Nama</label>
                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name') ? old('name') : $user->name); ?>" required>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username') ? old('username') : $user->username); ?>" required>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'username'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email') ? old('email') : $user->email); ?>" required>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <span class="text-danger" style="font-size: 12px">* kosongkan jika tidak ingin mengganti password</span>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <a href="<?php echo e(route('cp.users.index')); ?>" class="btn btn-secondary">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/user/edit.blade.php ENDPATH**/ ?>