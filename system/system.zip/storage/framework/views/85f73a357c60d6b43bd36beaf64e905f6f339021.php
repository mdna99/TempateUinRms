<?php $__env->startSection('content'); ?>
<div class="header-title">
    <h1><?php echo e($post->menu->title); ?></h1>
</div>
<div class="banner">
    <img src="<?php echo e(asset($cover)); ?>" onerror="this.src='<?php echo e(asset('assets/img/slider.JPG')); ?>'">
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid">
    <div class="post">
        <div class="row">
            <div class="col-md-4 d-none d-md-block d-lg-block">
                <div class="sidebar">
                    <ul>
                        <?php $__currentLoopData = $sidebars->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li <?php echo e($sidebar->title == $post->title ? 'class=active' : ''); ?>><a href="<?php echo e(generateUrl($sidebar->menu->slug.'/'.$sidebar->slug)); ?>"><?php echo e($sidebar->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-8" id="print-area">
                <div class="content">
                    <h1><?php echo e($post->title); ?></h1>
                    <?php echo $post->description; ?>

                    <?php if(count($post->files) != 0): ?>
                    <div class="attachment">
                        <h2>Download</h2>
                        <div class="file">
                            <?php $__currentLoopData = $post->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(asset($file->file)); ?>" target="_blank">
                                <!--<img src="<?php echo e(asset('assets/img/file.png')); ?>">-->
                                <?php echo e($file->title); ?>

                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if($post->thumbnail): ?>
        <img src="<?php echo e(asset($post->thumbnail)); ?>" class="cover">
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/templates/post/hidden.blade.php ENDPATH**/ ?>