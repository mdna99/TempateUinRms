<?php $__env->startSection('title', 'Interest Rate'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8">
        <form action="<?php echo e(route('cp.interest-rates.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>           

            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Edit Interest Rate</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="col-form-label"><?php echo e(__('homepage.simpanan_minimum')); ?></label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text">IDR</div>
                            </div>
                            <input type="text" class="form-control" name="interestrate[<?php echo e($minimum_deposit->key); ?>]" value="<?php echo e($minimum_deposit->value); ?>">
                        </div>
                    </div>  
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr class="">
                                    <th colspan="3" class="text-center"><?php echo e(__('homepage.suku_bunga')); ?></th>                                    
                                </tr>
                                <tr>
                                    <th><?php echo e(__('homepage.periode')); ?></th>
                                    <th>%</th>
                                    <th class="table-fit">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="input-group">
                                            <input type="text" class="form-control" value="<?php echo e($term->key); ?>" disabled="">
                                            <div class="input-group-append">
                                                <div class="input-group-text"><?php echo e(__('homepage.bulan')); ?><?php echo e(app()->getLocale() == 'en' && $term->key > 1 ? 's' : ''); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="interestrate[<?php echo e($term->key); ?>]" value="<?php echo e($term->value); ?>">
                                            <div class="input-group-append">
                                                <div class="input-group-text">%</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center" style="vertical-align: middle">
                                        <button class="btn btn-sm btn-danger delete-<?php echo e($term->id); ?>" type="button" onclick="deleteTerm(<?php echo e($term->id); ?>)"><i class="fa fa-trash"></i></button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Save
                    </button>
                </div>
            </div>
        </form>
    </div>
    <div class="col-lg-4">
        <form action="<?php echo e(route('cp.interest-rates.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Add <?php echo e(__('homepage.periode')); ?></h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="key" class="col-form-label text-right"><?php echo e(__('homepage.periode')); ?></label>
                        <div class="input-group">
                            <input type="text" class="form-control<?php echo e($errors->has('key') ? ' is-invalid' : ''); ?>" name="key" value="<?php echo e(old('key')); ?>">
                            <div class="input-group-append">
                                <div class="input-group-text">bulan</div>
                            </div>
                        </div>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'key'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>                    
                    <div class="form-group">
                        <label for="value" class="col-form-label text-right">%</label>
                        <div class="input-group">
                            <input type="text" class="form-control<?php echo e($errors->has('value') ? ' is-invalid' : ''); ?>" name="value" value="<?php echo e(old('value')); ?>">
                            <div class="input-group-append">
                                <div class="input-group-text">%</div>
                            </div>
                        </div>
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'value'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>                    
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Add
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    function deleteTerm(id) {
        var done = confirm('Are you sure want to delete it ?');
        if (done) {
            $.ajax({
                type: "DELETE",
                url: "<?php echo e(route('cp.interest-rates.destroy')); ?>",
                data: {id: id},
                success: function (result) {
                    if (result) {
                        var tableParent = $('.delete-' + id).closest('table');
                        var trParent = $('.delete-' + id).closest('tr');
                        trParent.remove();
                        alert('<?php echo e(__('homepage.periode')); ?>'+' deleted');
                    } else {
                        alert('failed to delete ')+'<?php echo e(__('homepage.periode')); ?>';
                    }
                }
            });
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/cp/interest-rate/edit.blade.php ENDPATH**/ ?>