<div class="header-title">
    <?php if(isset($post)): ?>
    <?php if($post->menu->id == 4 || $post->menu->id == 8 || $post->menu->id == 9 || $post->menu->id == 10 || $post->menu->id == 11): ?>
    <?php if($breadcrumbs[1]->title == $post->title): ?>
    <h1><?php echo e($breadcrumbs[0]->title); ?></h1>
    <?php else: ?>
    <h1><?php echo e($breadcrumbs[1]->title); ?></h1>
    <?php endif; ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a>
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <?php if($key == (count($breadcrumbs)-1)): ?>
        <a>Detail</a>
        <?php else: ?>
        <a><?php echo e($breadcrumb->title); ?></a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <?php if(isset($breadcrumbs[1]->title)): ?>
    <h1><?php echo e($breadcrumbs[1]->title); ?></h1>
    <?php elseif(isset($post->title)): ?>
    <h1><?php echo e($post->title); ?></h1>
    <?php else: ?>
    <h1><?php echo e($menu->title); ?></h1>
    <?php endif; ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a>
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($breadcrumb->title != 'Page'): ?>
        <a><?php echo e($breadcrumb->title); ?></a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(isset($menu)): ?>
    <?php if($menu->id == 4 || $menu->id == 8 || $menu->id == 9 || $menu->id == 10 || $menu->id == 11): ?>
    <?php if(isset($breadcrumbs[1]->title)): ?>
    <h1><?php echo e($breadcrumbs[1]->title); ?></h1>
    <?php else: ?>
    <h1><?php echo e($breadcrumbs[0]->title); ?></h1>
    <?php endif; ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a>
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($breadcrumb->title != 'Page'): ?>
        <a><?php echo e($breadcrumb->title); ?></a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <?php if(isset($breadcrumbs[1]->title)): ?>
    <h1><?php echo e($breadcrumbs[1]->title); ?></h1>
    <?php elseif(isset($post->title)): ?>
    <h1><?php echo e($post->title); ?></h1>
    <?php else: ?>
    <h1><?php echo e($menu->title); ?></h1>
    <?php endif; ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('')); ?>"><?php echo e(__('breadcrumb.home')); ?></a>
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($breadcrumb->title != 'Page'): ?>
        <a><?php echo e($breadcrumb->title); ?></a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>    
    <?php endif; ?>    
</div><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/components/title.blade.php ENDPATH**/ ?>