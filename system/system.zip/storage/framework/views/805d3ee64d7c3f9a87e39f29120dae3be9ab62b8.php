<?php $__env->startSection('title'); ?>
    <div class="section-header-back">
      <a href="<?php echo e(route('cp.retirement-calculations.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    </div>
    <h1>Detail Hasil Kalkulasi Pinjaman</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Created at <?php echo e($calculation->created_at->format('d F Y')); ?> - <?php echo e($calculation->created_at->format('H:i')); ?></h4>
            </div>
            <div class="card-body">
                <dl class="row">
                    <dt class="col-3 text-right">Nama</dt>
                    <dd class="col-9"><?php echo e($calculation->name); ?></dd>
                    
                    <dt class="col-3 text-right">Perusahaan</dt>
                    <dd class="col-9"><?php echo e($calculation->company); ?></dd>

                    <dt class="col-3 text-right">Tanggal Lahir</dt>
                    <dd class="col-9"><?php echo e($calculation->birth_date); ?></dd>

                    <dt class="col-3 text-right">Umur</dt>
                    <dd class="col-9"><?php echo e(getAge($calculation->birth_date)); ?> Tahun</dd>

                    <dt class="col-3 text-right">Lokasi</dt>
                    <dd class="col-9"><?php echo e($calculation->location); ?></dd>

                    <dt class="col-3 text-right">Nomor HP</dt>
                    <dd class="col-9"><?php echo e($calculation->phone); ?></dd>
                    
                    <dt class="col-3 text-right">Email</dt>
                    <dd class="col-9"><?php echo e($calculation->email ? $calculation->email : '-'); ?></dd>
                    
                    <dt class="col-3 text-right">Gaji</dt>
                    <dd class="col-9">Rp <?php echo e(number_format($calculation->salary,2,",",".")); ?></dd>
                    
                    <dt class="col-3 text-right">Maksimal Pinjaman</dt>
                    <dd class="col-9">Rp <?php echo e(number_format($calculation->max_loan,2,",",".")); ?></dd>
                </dl>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0\htdocs\bc\system\resources\views/cp/retirement-calculations/show.blade.php ENDPATH**/ ?>