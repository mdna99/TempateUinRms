<table>
    <thead>
        <tr>
            <th>NO</th>
            <th>AREA</th>
            <th>UNIT</th>
            <th>ADDRESS</th>
            <th>PHONE</th>
            <th>FAX</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($locations) != 0): ?>
        <?php
        $rowNumber = 1;
        ?>
        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($rowNumber++); ?></td>
            <td><?php echo e($location->area->name); ?></td>
            <td><?php echo e($location->unit); ?></td>
            <td>
                <?php echo $location->address; ?>

            </td>
            <td><?php echo e($location->phone); ?></td>
            <td><?php echo e($location->fax); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="6">No data</td>
        </tr>
        <?php endif; ?>                                
    </tbody>
</table><?php /**PATH /home/bankcapi/public_html/system/resources/views/templates/location/table.blade.php ENDPATH**/ ?>