<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <?php if($parent->parent_id == 0): ?>
    <a href="<?php echo e(route("cp.menu.show",$parent->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php else: ?>
    <a href="<?php echo e(route('cp.menu.submenu.show',[$parent->parent_id,$parent->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php endif; ?>
</div>
<h1><?php echo e($menu->title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-8">
        <div class="card">
            <div class="card-header py-0">
                <h4 class="text-black-50">Konten</h4>
            </div>
            <div class="card-body py-0">
                <dl class="meta">
                    <dt>Title</dt>
                    <dd><?php echo e($menu->title); ?></dd>

                    <dt>Description</dt>
                    <dd><?php echo strip_tags($menu->description); ?></dd>
                </dl>
            </div>
        </div>
    </div>
    <div class="col-4">
        <div class="card">
            <div class="card-header py-0">
                <h4 class="text-black-50">Meta</h4>
            </div>
            <div class="card-body py-0">
                <div class="form-group">
                    <label>Cover</label>
                    <div class="mb-2">
                        <img src="<?php echo e(asset($menu->cover)); ?>" class="img-fluid">
                    </div>                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php if($parent->id != 4): ?>
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="section-title m-0">
                Sub Menu
            </h2>
            <a href="<?php echo e(route('cp.menu.submenu.create',$menu)); ?>" class="btn btn-primary">Add New Sub Menu</a>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-4">
        <div class="article">
            <div class="article-header">
                <div class="article-image d-flex justify-content-center align-items-center">
                    <img src="<?php echo e(asset($submenu->cover)); ?>" style="width: 90%">
                </div>
                <div class="article-title">
                    <h2 class="text-light"><?php echo e($submenu->title); ?></h2>
                </div>
            </div>
            <div class="card-footer bg-whitesmoke">
                <div class="row align-items-center justify-content-between">
                    <div class="col-4 text-center"><a href="<?php echo e(route('cp.menu.submenu.show',[$menu, $submenu])); ?>" class="btn btn-sm btn-outline-success"><i class="fa fa-eye"></i> Detail</a></div>
                    <div class="col-4 text-center"><a href="<?php echo e(route('cp.menu.submenu.edit', [$menu, $submenu])); ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-pencil-alt"></i> Edit</a></div>
                    <div class="col-4 text-center">
                        <form id="form-action" method="POST" action="<?php echo e(route('cp.menu.submenu.destroy', [$menu, $submenu])); ?>" accept-charset="UTF-8">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Anda yakin akan menghapus data ?');">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12 text-center">  
        <div class="card card-primary">            
            <p class="m-0 py-3">Tidak Ada Data</p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="section-title m-0">
                Post
            </h2>
            <a href="<?php echo e(route('cp.menu.post.create',$menu)); ?>" class="btn btn-primary">Add New Post</a>
        </div>
        <div class="card card-primary">         
            <div class="card-body p-0">
                <table class="table table-striped table-md">
                    <thead>
                        <tr>
                            <th class="table-fit">#</th>
                            <th>Title</th>
                            <th class="table-fit">Published At</th>
                            <th class="table-fit">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $rowNumber = ($posts->currentpage()-1) * $posts->perpage() + 1;
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="table-fit"><?php echo e($rowNumber++); ?></td>
                            <td><?php echo e($post->title); ?></td>
                            <td class="table-fit"><?php echo e($post->created_at->format('d F Y')); ?></td>
                            <td class="table-fit">
                                <form id="form-action" method="POST" action="<?php echo e(route('cp.menu.post.destroy', [$menu,$post])); ?>" accept-charset="UTF-8">
                                    <input name="_method" type="hidden" value="DELETE">
                                    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">

                                    <div class="table-links">
                                        <a href="<?php echo e(route('cp.menu.post.show',[$menu->id, $post->id])); ?>">Detail</a>
                                        <div class="bullet"></div>
                                        <a href="<?php echo e(route('cp.menu.post.edit',[$menu->id, $post->id])); ?>">Edit</a>
                                        <div class="bullet"></div>
                                        <button type="submit" class="btn text-danger btn-link" onclick="return confirm('Anda yakin akan menghapus data ?');">
                                            Delete
                                        </button>
                                        <?php if($parent->id == 4): ?>
                                        <div class="bullet"></div>
                                        <a href="<?php echo e(route('cp.createsliderfrompost', ['parent_id'=>$parent->id, 'id'=>$post->id])); ?>">
                                            <i class="fa fa-image"></i> Add to Slider
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="px-2">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/cp/submenu/show.blade.php ENDPATH**/ ?>