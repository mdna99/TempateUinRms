

<?php $__env->startSection('title'); ?>
<div class="section-header-back">
    <?php if($menu->parent_id == 0): ?>
    <a href="<?php echo e(route('cp.menus.show',$menu->id)); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php else: ?>
    <a href="<?php echo e(route('cp.menus.submenus.show',[$menu->parent_id,$menu->id])); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    <?php endif; ?>
</div>
<h1>Detail Post</h1>
<?php echo $__env->make('cp.components.breadcrumb', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link <?php echo e(app()->getLocale() == 'id' ? 'active' : ''); ?>" id="id-tab" data-toggle="tab" href="#id" role="tab" aria-controls="id" aria-selected="true">Indonesia</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>" id="en-tab" data-toggle="tab" href="#en" role="tab" aria-controls="en" aria-selected="false">English</a>
    </li>
</ul>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="tab-content" id="myTabContent">
                <div class="p-0 tab-pane fade <?php echo e(app()->getLocale() == 'id' ? 'show active' : ''); ?>" id="id" role="tabpanel" aria-labelledby="id-tab">
                    <div class="card-header flex-column align-items-start">
                        <h2 class="section-title my-0">
                            <?php echo e($post->translate('id')->title); ?>                            
                        </h2>
                        <a class="mt-2" href="<?php echo e(url('id/'.$post->translate('id')->slug)); ?>" target="_blank" style="font-size: 11px; line-height: 11px"><?php echo e(url('id/'.$post->translate('id')->slug)); ?> <i class="fa fa-external-link-alt"></i></a>
                    </div>
                    <div class="card-body">
                        <dl class="meta">
                            <dt>Description</dt>
                            <dd><?php echo $post->translate('id')->description; ?></dd>
                        </dl>  
                    </div>
                </div>
                <div class="p-0 tab-pane fade <?php echo e(app()->getLocale() == 'en' ? 'show active' : ''); ?>" id="en" role="tabpanel" aria-labelledby="en-tab">
                    <div class="card-header flex-column align-items-start">
                        <h2 class="section-title my-0">
                            <?php echo e($post->translate('en')->title); ?>

                        </h2>
                        <a class="mt-2" href="<?php echo e(url('en/'.$post->translate('en')->slug)); ?>" target="_blank" style="font-size: 11px; line-height: 11px"><?php echo e(url('en/'.$post->translate('en')->slug)); ?> <i class="fa fa-external-link-alt"></i></a>
                    </div>
                    <div class="card-body">
                        <dl class="meta">
                            <dt>Description</dt>
                            <dd><?php echo $post->translate('en')->description; ?></dd>
                        </dl>  
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h4 class="text-black-50">Meta</h4>
            </div>
            <div class="card-body">
                <dl class="meta">                
                    <dd>
                        <span style="font-size: 11px" class="badge badge-<?php echo e($post->is_published == 1 ? 'primary' : 'warning'); ?> px-2 py-1"><?php echo e($post->is_published == 1 ? 'Published' : 'Draft'); ?></span>
                        <?php if($post->is_running_text): ?>
                        <span style="font-size: 11px" class="badge badge-info px-2 py-1">Running Text</span>
                        <?php endif; ?>
                        <?php if($post->is_featured_product): ?>
                        <span style="font-size: 11px" class="badge badge-danger px-2 py-1">Featured Product</span>
                        <?php endif; ?>
                    </dd>

                    <dt>Published At</dt>
                    <dd><?php echo e($post->created_at->format('d F Y')); ?></dd>

                    <dt>Cover Image</dt>
                    <dd>
                        <?php if($post->cover): ?>
                        <img src="<?php echo e(asset($post->cover)); ?>" class="img-fluid" alt="">
                        <?php else: ?>
                        None
                        <?php endif; ?>
                    </dd>

                    <dt>Thumbnail Image</dt>
                    <dd>
                        <?php if($post->thumbnail): ?>
                        <img src="<?php echo e(asset($post->thumbnail)); ?>" class="img-fluid" alt="">
                        <?php else: ?>
                        None
                        <?php endif; ?>
                    </dd>

                    <dt>Template Page</dt>
                    <dd><?php echo e($post->template); ?></dd>
                </dl>
            </div>
        </div>
        <?php if(count($post->files) != 0): ?>
        <div class="card">
            <div class="card-header">
                <h4 class="text-black-50">Files</h4>
            </div>
            <div class="card-body d-flex flex-column">
                <?php $__currentLoopData = $post->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge badge-secondary mb-2"><i class="fas fa-file"></i>&nbsp;
                    <a class="text-white" href="<?php echo e(asset($file->file)); ?>" target="_blank"><?php echo e($file->title); ?></a>
                </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                   
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php if($post->id == 3): ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="text-black-50">Location</h4>            
            </div>
            <div class="card-body">
                <table class="table table-responsive">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Area</th>
                            <th scope="col">Unit</th>
                            <th scope="col">Address</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Fax</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $rowNumber = ($locations->currentpage()-1) * $locations->perpage() + 1;
                        ?>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="table-fit"><?php echo e($rowNumber++); ?></td>
                            <td class="table-fit"><?php echo e($location->area->name); ?></td>
                            <td class="table-fit"><?php echo e($location->unit); ?></td>
                            <td class="table-fit"><?php echo $location->address; ?></td>
                            <td class="table-fit"><?php echo e($location->phone); ?></td>
                            <td class="table-fit"><?php echo e($location->fax); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/dev/system/resources/views/cp/post/show.blade.php ENDPATH**/ ?>