

<?php $__env->startSection('title', 'Change Password'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.passwords.update')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" class="form-control<?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>" name="new_password" autofocus="">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'new_password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>                
                    <div class="form-group">
                        <label for="new_confirm_password">New Password Confirmation</label>
                        <input type="password" id="new_confirm_password" class="form-control<?php echo e($errors->has('new_confirm_password') ? ' is-invalid' : ''); ?>" name="new_confirm_password" autofocus="">
                        <?php echo $__env->make('cp.components.form-error', ['field' => 'new_confirm_password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>                    
                </div>
                <div class="card-footer bg-whitesmoke">
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/system/resources/views/cp/changepassword/edit.blade.php ENDPATH**/ ?>