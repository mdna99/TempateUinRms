<?php $__env->startSection('title'); ?>
    <div class="section-header-back">
      <a href="<?php echo e(route('cp.sliders.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
    </div>
    <h1>Slider</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cp.sliders.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-black-50">Konten</h4>
                </div>
                <div class="card-body">
                    <div class="form-group row align-items-center">
                        <label for="image" class="col-sm-3 col-form-label text-right">Image</label>
                        <div class="col-sm-6">
                            <div class="mb-2">
                                <img src="" class="img-fluid" alt="" id="upload-img-preview" style="display: none;">
                                <a href="#" class="text-danger" id="upload-img-delete" style="display: none;">Delete Cover Image</a>
                            </div>
                            <div class="custom-file">
                                <input type="file" accept="image/*" name="image" id="image" class="custom-file-input js-upload-image form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>">
                                <label class="custom-file-label " for="image">Choose file</label>
                                <?php echo $__env->make('cp.components.form-error', ['field' => 'image'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="caption" class="col-sm-3 col-form-label text-right">Caption</label>
                        <div class="col-sm-6">
                            <textarea id="caption" cols="30" rows="5" class="form-control<?php echo e($errors->has('caption') ? ' is-invalid' : ''); ?>" style="height: auto;" name="caption"><?php echo e(old('caption')); ?></textarea>
                            <?php echo $__env->make('cp.components.form-error', ['field' => 'caption'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke">
                    <div class="col-sm-6 offset-sm-3">
                        <button type="submit" class="btn btn-primary">
                            Simpan
                        </button>
                        <a href="<?php echo e(route('cp.sliders.index')); ?>" class="btn btn-secondary">
                            Batal
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\bankcapital\resources\views/cp/slider/create.blade.php ENDPATH**/ ?>