<meta name="description" content="<?php echo e(strip_tags(data_get($setting, 'tagline', '-'))); ?>"/>
<meta name="author" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />
<meta name="copyright" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />
<meta name="application-name" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />

<?php if($page == 'home'): ?>
<meta property="og:title" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />
<meta property="og:type" content="article" />
<meta property="og:image" content="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>" />
<meta property="og:image:alt" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:url" content="<?php echo e(url('')); ?>" />
<meta property="og:description" content="<?php echo e(strip_tags(data_get($setting, 'tagline', '-'))); ?>" />

<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="<?php echo e(data_get($setting, 'name', '-')); ?>" />
<meta name="twitter:description" content="<?php echo e(strip_tags(data_get($setting, 'tagline', '-'))); ?>" />
<meta name="twitter:image" content="<?php echo e(asset(data_get($setting, 'icon', '-'))); ?>" />
<?php elseif($page == 'submenu'): ?>
<meta property="og:title" content="<?php echo e(data_get($setting, 'name', '-').' | '.$submenu->title); ?>" />
<meta property="og:type" content="article" />
<meta property="og:image" content="<?php echo e(asset(!empty($submenu->cover) ? $submenu->cover : data_get($setting, 'icon'))); ?>" />
<meta property="og:image:alt" content="<?php echo e($submenu->title); ?>" />
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:url" content="<?php echo e(url($submenu->slug)); ?>" />
<meta property="og:description" content="<?php echo e(strip_tags($submenu->description)); ?>" />

<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="<?php echo e(data_get($setting, 'name', '-').' | '.$submenu->title); ?>" />
<meta name="twitter:description" content="<?php echo e(strip_tags($submenu->description)); ?>" />
<meta name="twitter:image" content="<?php echo e(asset(!empty($submenu->cover) ? $submenu->cover : data_get($setting, 'icon'))); ?>" />
<?php elseif($page == 'post'): ?>
<meta property="og:title" content="<?php echo e(data_get($setting, 'name', '-').' | '.$post->title); ?>" />
<meta property="og:type" content="article" />
<meta property="og:image" content="<?php echo e(asset(!empty($post->cover) ? $post->cover : data_get($setting, 'icon'))); ?>" />
<meta property="og:image:alt" content="<?php echo e($post->title); ?>" />
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:url" content="<?php echo e(url('')); ?>" />
<meta property="og:description" content="<?php echo e(strip_tags($post->description)); ?>" />

<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="<?php echo e(data_get($setting, 'name', '-').' | '.$post->title); ?>" />
<meta name="twitter:description" content="<?php echo e(strip_tags($post->description)); ?>" />
<meta name="twitter:image" content="<?php echo e(asset(!empty($post->cover) ? $post->cover : data_get($setting, 'icon'))); ?>" />
<?php endif; ?><?php /**PATH C:\xampp7.3\htdocs\simpldesign\resources\views/components/meta.blade.php ENDPATH**/ ?>