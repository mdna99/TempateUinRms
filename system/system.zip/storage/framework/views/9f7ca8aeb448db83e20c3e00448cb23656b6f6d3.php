<div class="section-header-breadcrumb">
    <div class="breadcrumb-item"><a href="<?php echo e(url('cp')); ?>">Dashboard</a></div>
    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key == (count($breadcrumbs)-1)): ?>
    <div class="breadcrumb-item"><?php echo e($breadcrumb->title); ?></div>
    <?php elseif($key == 0): ?>
    <div class="breadcrumb-item"><a href="<?php echo e(route("cp.menus.show",$breadcrumb->id)); ?>"><?php echo e($breadcrumb->title); ?></a></div>
    <?php else: ?>
    <div class="breadcrumb-item"><a href="<?php echo e(route('cp.menus.submenus.show',[$breadcrumb->parent->id,$breadcrumb->id])); ?>"><?php echo e($breadcrumb->title); ?></a></div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp8.0\htdocs\uin\system\resources\views/cp/components/breadcrumb.blade.php ENDPATH**/ ?>