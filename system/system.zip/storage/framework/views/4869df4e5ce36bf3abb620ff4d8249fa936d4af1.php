

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.title', [
'breadcrumbs' => $breadcrumbs
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="banner">
    <img src="<?php echo e(asset($cover)); ?>" onerror="this.src='<?php echo e(asset('assets/img/slider.JPG')); ?>'">
</div>
<div class="white-bar">
    <div class="bar"></div>
</div>
<div class="container-fluid">
    <div class="post">
        <div class="row">
            <div class="col-md-4 d-none d-md-block d-lg-block">
                <div class="sidebar">
                    <ul>
                        <li class="active"><a href="<?php echo e(generateUrl($menu->slug)); ?>"><?php echo e($menu->title); ?></a></li>
                        <li><a href="<?php echo e(url('')); ?>">Home</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8" id="print-area">
                <div class="content">
                    <h1><?php echo e($menu->title); ?></h1>
                    <div class="career">
                        <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li>
                                <a href="<?php echo e(generateUrl($post->slug)); ?>">
                                    <?php echo e($post->title); ?>

                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h4 class="text-center">No data</h4>
                            <?php endif; ?>                                                                                         
                        </ul>
                    </div>                    
                    <?php if(count($posts->links()->elements[0]) > 1): ?>
                    <?php echo e($posts->links('components.pagination')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bankcapi/public_html/dev/system/resources/views/templates/menu/list.blade.php ENDPATH**/ ?>