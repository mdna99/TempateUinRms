## Bank Capital
> Bank Capital Website

### Installation
Clone this repo, and

```sh
composer install
cp .env.example .env
php artisan key:generate
#Setting database on .env
```