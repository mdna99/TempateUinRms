<?php

namespace App\Http\Controllers;

use App\Menu;
use App\Post;

class HomeController extends Controller
{

        public function index()
        {
                // $userIp = $request->ip();
                // $locationData = Location::get($userIp);

                // dd($locationData);
                return view('index', [
                        'latestnews' => Post::where('menu_id', 1)
                                ->isActive()
                                ->orderBy('created_at', 'DESC')
                                ->take(4)
                                ->get(),
                        'homemenus' => Menu::where('parent_id', 0)
                                ->isHomepageMenu()
                                ->isActive()
                                ->order()
                                ->with(['posts' => function ($query) {
                                        $query->isActive()
                                                ->orderBy('created_at', 'DESC')
                                                ->first();
                                }])
                                ->get(),
                        'education' => Menu::where('id', 2)
                                ->isActive()
                                ->first(),
                        'faculties' => Menu::where('parent_id', 3)
                                ->isActive()
                                ->get()
                ]);
        }
}
