<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class File extends Model {
    
    public $timestamps = false;

    protected $fillable = [
        'post_id', 'title', 'file', 'order'
    ];
    
    public function post() {
        return $this->belongsTo('App\Post');
    }
    
    protected static function boot() {
        parent::boot();

        static::deleting(function($file) {
            removeFile($file->file);
        });
    }

}
